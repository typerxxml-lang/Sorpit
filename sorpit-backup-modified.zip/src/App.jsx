import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Welcome from '@/pages/Welcome';
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
import Terms from '@/pages/Terms';
import Privacy from '@/pages/Privacy';
import AppShell from '@/components/AppShell';
import Home from '@/pages/Home';
import Projects from '@/pages/Projects';
import ProjectDetail from '@/pages/ProjectDetail';
import Library from '@/pages/Library';
import Files from '@/pages/Files';
import Images from '@/pages/Images';
import Notes from '@/pages/Notes';
import Links from '@/pages/Links';
import Favorites from '@/pages/Favorites';
import ArchivePage from '@/pages/Archive';
import Trash from '@/pages/Trash';
import SearchPage from '@/pages/Search';
import Settings from '@/pages/Settings';
import Tasks from '@/pages/Tasks';
import Folders from '@/pages/Folders';
import CustomTypes from '@/pages/CustomTypes';
import Templates from '@/pages/Templates';
import Automations from '@/pages/Automations';
import Notifications from '@/pages/Notifications';
import Activity from '@/pages/Activity';
import Explore from '@/pages/Explore';
import Developer from '@/pages/Developer';
import ShareView from '@/pages/ShareView';
import { ThemeProvider } from '@/lib/theme';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Welcome />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/terms" element={<Terms />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/share/:token" element={<ShareView />} />

      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<AppShell />}>
          <Route path="/app" element={<Home />} />
          <Route path="/app/projects" element={<Projects />} />
          <Route path="/app/projects/:id" element={<ProjectDetail />} />
          <Route path="/app/library" element={<Library />} />
          <Route path="/app/files" element={<Files />} />
          <Route path="/app/images" element={<Images />} />
          <Route path="/app/notes" element={<Notes />} />
          <Route path="/app/links" element={<Links />} />
          <Route path="/app/favorites" element={<Favorites />} />
          <Route path="/app/archive" element={<ArchivePage />} />
          <Route path="/app/trash" element={<Trash />} />
          <Route path="/app/search" element={<SearchPage />} />
          <Route path="/app/settings" element={<Settings />} />
          <Route path="/app/tasks" element={<Tasks />} />
          <Route path="/app/folders" element={<Folders />} />
          <Route path="/app/custom-types" element={<CustomTypes />} />
          <Route path="/app/templates" element={<Templates />} />
          <Route path="/app/automations" element={<Automations />} />
          <Route path="/app/notifications" element={<Notifications />} />
          <Route path="/app/activity" element={<Activity />} />
          <Route path="/app/explore" element={<Explore />} />
          <Route path="/app/developer" element={<Developer />} />
        </Route>
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <ThemeProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <ScrollToTop />
            <AuthenticatedApp />
          </Router>
          <Toaster />
        </QueryClientProvider>
      </ThemeProvider>
    </AuthProvider>
  )
}

export default App