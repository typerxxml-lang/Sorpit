import { useState } from "react";
import { FolderKanban, Plus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import ProjectCard from "@/components/ProjectCard";
import ProjectEditor from "@/components/ProjectEditor";
import EmptyState from "@/components/EmptyState";

export default function Projects() {
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const { items, loading } = useCollection(
    () =>
      base44.entities.Project.filter(
        { deleted_at: { $exists: false }, is_archived: { $ne: true } },
        { sort: "-updated_date", limit: 100 }
      ),
    []
  );

  const openNew = () => {
    setEditing(null);
    setEditorOpen(true);
  };
  const openEdit = (project) => {
    setEditing(project);
    setEditorOpen(true);
  };

  return (
    <div className="animate-fade-up">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span
            className="glass-soft flex h-11 w-11 items-center justify-center rounded-2xl"
            style={{ color: "hsl(var(--accent))" }}
          >
            <FolderKanban className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-xl font-extrabold leading-tight">المشاريع</h1>
            <p className="text-xs text-muted-foreground">{items.length} مشروع</p>
          </div>
        </div>
        <button
          onClick={openNew}
          className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold transition active:scale-95"
        >
          <Plus className="h-5 w-5" /> مشروع
        </button>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={FolderKanban}
          title="لا توجد مشاريع بعد"
          description="أنشئ أول مشروع لتنظيم ملفاتك وأفكارك ومهامك حوله."
          action={
            <button
              onClick={openNew}
              className="glass-pill flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition active:scale-95"
            >
              <Plus className="h-4 w-4" /> إنشاء مشروع
            </button>
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {items.map((p) => (
            <ProjectCard key={p.id} project={p} onEdit={openEdit} />
          ))}
        </div>
      )}

      <ProjectEditor open={editorOpen} onOpenChange={setEditorOpen} project={editing} />
    </div>
  );
}