import { Trash2, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import ItemCard from "@/components/ItemCard";
import EmptyState from "@/components/EmptyState";
import { useState } from "react";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";

export default function Trash() {
  const { items, loading } = useCollection(
    () => base44.entities.Item.filter({ deleted_at: { $exists: true } }, { sort: "-updated_date", limit: 100 }),
    []
  );
  const [emptying, setEmptying] = useState(false);

  const emptyTrash = async () => {
    if (!items.length) return;
    setEmptying(true);
    try {
      await base44.entities.Item.deleteMany({ deleted_at: { $exists: true } });
      toast({ title: "أُفرغت السلة" });
      emitDataChanged();
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setEmptying(false);
    }
  };

  return (
    <div className="animate-fade-up">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="glass-soft flex h-11 w-11 items-center justify-center rounded-2xl text-destructive">
            <Trash2 className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-xl font-extrabold leading-tight">سلة المحذوفات</h1>
            <p className="text-xs text-muted-foreground">يمكنك استعادة العناصر أو حذفها نهائيًا</p>
          </div>
        </div>
        {items.length > 0 && (
          <button
            onClick={emptyTrash}
            disabled={emptying}
            className="glass-soft flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold text-destructive transition active:scale-95"
          >
            {emptying ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
            إفراغ السلة
          </button>
        )}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState icon={Trash2} title="السلة فارغة" description="لا توجد عناصر محذوفة." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((it) => (
            <ItemCard key={it.id} item={it} />
          ))}
        </div>
      )}
    </div>
  );
}