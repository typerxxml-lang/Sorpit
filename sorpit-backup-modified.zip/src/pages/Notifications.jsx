import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import { Bell, CheckCheck, Trash2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import { toast } from "@/components/ui/use-toast";
import { timeAgo } from "@/lib/itemHelpers";
import { emitDataChanged } from "@/lib/dataEvents";

export default function Notifications() {
  const { items, loading } = useCollection(
    () => base44.entities.Notification.filter({}, { sort: "-created_date", limit: 100 })
  );
  const [busy, setBusy] = useState(false);

  const markAll = async () => {
    setBusy(true);
    try {
      await base44.entities.Notification.updateMany({ is_read: { $ne: true } }, { $set: { is_read: true } });
      emitDataChanged();
      toast({ title: "تم تعليم الكل كمقروء" });
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const remove = async (n) => {
    try {
      await base44.entities.Notification.delete(n.id);
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="الإشعارات"
        subtitle="كل تنبيهاتك في مكان واحد"
        action={
          <button onClick={markAll} disabled={busy} className="glass-soft flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <CheckCheck className="h-4 w-4" /> تعليم الكل
          </button>
        }
      />
      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا إشعارات" description="ستظهر هنا تنبيهاتك." />
      ) : (
        <div className="space-y-2">
          {items.map((n) => (
            <div key={n.id} className={`glass flex items-start gap-3 rounded-3xl p-4 ${n.is_read ? "opacity-60" : ""}`}>
              <div className="glass-soft flex h-9 w-9 shrink-0 items-center justify-center rounded-xl">
                <Bell className="h-4 w-4" style={{ color: "hsl(var(--accent))" }} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold">{n.title}</p>
                {n.body && <p className="mt-0.5 text-sm text-muted-foreground">{n.body}</p>}
                <p className="mt-1 text-xs text-muted-foreground">{timeAgo(n.created_date)}</p>
              </div>
              {!n.is_read && <span className="mt-1 h-2 w-2 shrink-0 rounded-full" style={{ background: "hsl(var(--accent))" }} />}
              <button onClick={() => remove(n)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Trash2 className="h-4 w-4 text-destructive" /></button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}