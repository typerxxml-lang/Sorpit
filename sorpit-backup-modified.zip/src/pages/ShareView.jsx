import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import BrandLogo from "@/components/BrandLogo";
import Background from "@/components/Background";
import { FileText, Image as ImageIcon, Link2, StickyNote, Download, ExternalLink, Clock } from "lucide-react";

const TYPE_ICON = { note: StickyNote, image: ImageIcon, file: FileText, link: Link2 };

export default function ShareView() {
  const { token } = useParams();
  const [state, setState] = useState({ loading: true });

  useEffect(() => {
    base44.functions
      .invoke("getShare", { token })
      .then((res) => setState({ loading: false, data: res.data }))
      .catch(() => setState({ loading: false, error: true }));
  }, [token]);

  if (state.loading) {
    return (
      <div className="relative flex min-h-screen items-center justify-center">
        <Background />
        <p className="text-sm text-muted-foreground">جارٍ التحميل…</p>
      </div>
    );
  }

  const data = state.data;
  const expired = state.error || !data || data.status !== "ok";

  if (expired) {
    return (
      <div className="relative flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <Background />
        <div className="glass relative z-10 w-full max-w-md rounded-[2rem] p-8">
          <div className="glass-soft mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-2xl">
            <Clock className="h-7 w-7 text-muted-foreground" />
          </div>
          <h1 className="text-xl font-extrabold">انتهت صلاحية الرابط</h1>
          <p className="mt-2 text-sm text-muted-foreground">هذا الرابط لم يعد صالحًا أو انتهت مدته. تواصل مع المُرسِل لطلب رابط جديد.</p>
        </div>
      </div>
    );
  }

  const item = data.item;
  const Icon = TYPE_ICON[item.type] || FileText;

  return (
    <div className="relative min-h-screen">
      <Background />
      <div className="relative z-10 mx-auto max-w-2xl px-4 py-10">
        <div className="mb-6 flex items-center gap-3">
          <BrandLogo size={40} />
          <div>
            <p className="text-sm font-bold">Sorpit</p>
            <p className="text-xs text-muted-foreground">عُنصر مُشارك معك</p>
          </div>
        </div>
        <div className="glass rounded-[2rem] p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="glass-soft flex h-12 w-12 items-center justify-center rounded-2xl">
              <Icon className="h-6 w-6" style={{ color: "hsl(var(--accent))" }} />
            </div>
            <h1 className="text-xl font-extrabold">{item.title}</h1>
          </div>
          {item.description && <p className="mb-4 text-sm text-muted-foreground">{item.description}</p>}
          {item.type === "note" && (
            <div className="glass-soft rounded-2xl p-4 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: item.content || "" }} />
          )}
          {item.type === "link" && (
            <a href={item.url} target="_blank" rel="noreferrer" className="glass-pill inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold">
              <ExternalLink className="h-4 w-4" /> فتح الرابط
            </a>
          )}
          {item.type === "image" && item.file_url && (
            <img src={item.file_url} alt={item.title} className="glass-soft w-full rounded-2xl object-contain" />
          )}
          {item.type === "file" && item.file_url && (
            <a href={item.file_url} download={item.file_name} className="glass-pill inline-flex items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold">
              <Download className="h-4 w-4" /> تنزيل {item.file_name}
            </a>
          )}
        </div>
      </div>
    </div>
  );
}