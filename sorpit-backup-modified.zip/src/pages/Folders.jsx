import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, Folder, Pencil, Trash2, Loader2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";
import { ACCENTS } from "@/lib/theme";

export default function Folders() {
  const { items, loading } = useCollection(
    () => base44.entities.Folder.filter({ deleted_at: { $exists: false } }, { sort: "-created_date", limit: 100 })
  );
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [name, setName] = useState("");
  const [color, setColor] = useState("");
  const [saving, setSaving] = useState(false);

  const openNew = () => { setEditing(null); setName(""); setColor(""); setOpen(true); };
  const openEdit = (f) => { setEditing(f); setName(f.name); setColor(f.color || ""); setOpen(true); };

  const save = async () => {
    if (!name.trim()) { toast({ title: "الاسم مطلوب", variant: "destructive" }); return; }
    setSaving(true);
    try {
      const payload = { name: name.trim(), color: color || "" };
      if (editing) await base44.entities.Folder.update(editing.id, payload);
      else {
        const c = await base44.entities.Folder.create(payload);
        await logActivity("create", `مجلد جديد: ${payload.name}`, { entity_type: "Folder", entity_id: c.id });
      }
      toast({ title: editing ? "تم الحفظ" : "تم إنشاء المجلد" });
      emitDataChanged();
      setOpen(false);
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const remove = async (f) => {
    try {
      await base44.entities.Folder.update(f.id, { deleted_at: new Date().toISOString() });
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="المجلدات"
        subtitle="نظّم عناصرك في مجموعات"
        action={
          <button onClick={openNew} className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <Plus className="h-5 w-5" /> جديد
          </button>
        }
      />
      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا مجلدات" description="أنشئ مجلدًا لتنظيم عناصرك." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {items.map((f) => (
            <div key={f.id} className="glass flex flex-col items-center rounded-3xl p-5">
              <div className="glass-soft mb-3 flex h-14 w-14 items-center justify-center rounded-2xl">
                <Folder className="h-7 w-7" style={f.color ? { color: `hsl(${f.color})` } : { color: "hsl(var(--accent))" }} />
              </div>
              <p className="text-center font-bold leading-tight">{f.name}</p>
              <div className="mt-3 flex gap-1">
                <button onClick={() => openEdit(f)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => remove(f)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Trash2 className="h-4 w-4 text-destructive" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="glass rounded-[2rem] p-0 sm:max-w-sm">
          <DialogHeader className="px-6 pt-6 text-right">
            <DialogTitle>{editing ? "تعديل المجلد" : "مجلد جديد"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 px-6 py-4">
            <div className="space-y-2">
              <Label>الاسم</Label>
              <Input value={name} onChange={(e) => setName(e.target.value)} className="h-11 rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label>اللون</Label>
              <div className="flex flex-wrap gap-2">
                <button type="button" onClick={() => setColor("")} className={`h-8 w-8 rounded-full border-2 ${!color ? "border-foreground" : "border-transparent"}`} style={{ background: "hsl(var(--muted))" }} />
                {Object.entries(ACCENTS).map(([k, v]) => (
                  <button key={k} type="button" onClick={() => setColor(v)} className={`h-8 w-8 rounded-full border-2 ${color === v ? "border-foreground" : "border-transparent"}`} style={{ background: `hsl(${v})` }} />
                ))}
              </div>
            </div>
          </div>
          <div className="glass rounded-b-[2rem] px-6 py-4">
            <DialogFooter className="gap-2">
              <Button variant="ghost" onClick={() => setOpen(false)} className="rounded-xl">إلغاء</Button>
              <Button onClick={save} disabled={saving} className="rounded-xl">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "حفظ"}</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}