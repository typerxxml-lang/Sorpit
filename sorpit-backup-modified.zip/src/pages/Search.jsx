import { useEffect, useState } from "react";
import { Search as SearchIcon, Loader2, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import ItemCard from "@/components/ItemCard";
import { TYPE_META } from "@/lib/itemHelpers";

const TYPES = [
  { key: "all", label: "الكل" },
  { key: "note", label: "نصوص" },
  { key: "image", label: "صور" },
  { key: "file", label: "ملفات" },
  { key: "link", label: "روابط" },
];

export default function Search() {
  const [q, setQ] = useState("");
  const [debounced, setDebounced] = useState("");
  const [type, setType] = useState("all");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setDebounced(q.trim()), 300);
    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    if (!debounced) {
      setResults([]);
      return;
    }
    let active = true;
    setLoading(true);
    const base = { deleted_at: { $exists: false }, is_archived: { $ne: true } };
    const typeFilter = type === "all" ? {} : { type };
    const query = {
      ...base,
      ...typeFilter,
      $or: [
        { title: { $regex: debounced, $options: "i" } },
        { description: { $regex: debounced, $options: "i" } },
        { content: { $regex: debounced, $options: "i" } },
      ],
    };
    base44.entities.Item
      .filter(query, { sort: "-updated_date", limit: 60 })
      .then((res) => active && setResults(res.items || []))
      .catch(() => active && setResults([]))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [debounced, type]);

  return (
    <div className="animate-fade-up">
      <div className="glass flex items-center gap-2 rounded-2xl px-4 py-3">
        <SearchIcon className="h-5 w-5 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          autoFocus
          placeholder="ابحث في كل محتواك…"
          className="flex-1 bg-transparent text-base outline-none placeholder:text-muted-foreground"
        />
        {q && (
          <button onClick={() => setQ("")} className="text-muted-foreground">
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      <div className="no-scrollbar mt-4 flex gap-2 overflow-x-auto pb-1">
        {TYPES.map((t) => (
          <button
            key={t.key}
            onClick={() => setType(t.key)}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold transition ${type === t.key ? "glass-pill" : "glass-soft text-muted-foreground"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="mt-5">
        {loading ? (
          <div className="flex justify-center py-16">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : !debounced ? (
          <p className="py-16 text-center text-sm text-muted-foreground">اكتب كلمة للبحث في عناصرك.</p>
        ) : results.length === 0 ? (
          <p className="py-16 text-center text-sm text-muted-foreground">لا توجد نتائج. جرّب كلمات أخرى.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {results.map((it) => (
              <ItemCard key={it.id} item={it} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}