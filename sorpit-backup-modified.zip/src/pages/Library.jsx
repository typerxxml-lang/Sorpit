import { useState } from "react";
import { LayoutGrid, Loader2, Search as SearchIcon } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import ItemCard from "@/components/ItemCard";
import { TYPE_META } from "@/lib/itemHelpers";

const TYPES = [
  { key: "all", label: "الكل" },
  { key: "note", label: "نصوص" },
  { key: "image", label: "صور" },
  { key: "file", label: "ملفات" },
  { key: "link", label: "روابط" },
];

export default function Library() {
  const [type, setType] = useState("all");
  const [view, setView] = useState("grid");

  const baseFilter = { deleted_at: { $exists: false }, is_archived: { $ne: true } };
  const filter = type === "all" ? baseFilter : { ...baseFilter, type };
  const filterKey = JSON.stringify(filter);

  const { items, loading } = useCollection(
    () => base44.entities.Item.filter(filter, { sort: "-updated_date", limit: 100 }),
    [filterKey]
  );

  return (
    <div className="animate-fade-up">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <span className="glass-soft flex h-11 w-11 items-center justify-center rounded-2xl" style={{ color: "hsl(var(--accent))" }}>
            <LayoutGrid className="h-6 w-6" />
          </span>
          <div>
            <h1 className="text-xl font-extrabold leading-tight">المكتبة الرقمية</h1>
            <p className="text-xs text-muted-foreground">كل عناصرك في مكان واحد</p>
          </div>
        </div>
        <div className="glass-soft flex rounded-2xl p-1">
          <button onClick={() => setView("grid")} className={`flex h-8 w-8 items-center justify-center rounded-xl ${view === "grid" ? "glass-pill" : ""}`}>
            <LayoutGrid className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto pb-1">
        {TYPES.map((t) => (
          <button
            key={t.key}
            onClick={() => setType(t.key)}
            className={`shrink-0 rounded-full px-4 py-2 text-sm font-bold transition ${type === t.key ? "glass-pill" : "glass-soft text-muted-foreground"}`}
          >
            {t.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
        </div>
      ) : items.length === 0 ? (
        <div className="py-16 text-center text-sm text-muted-foreground">لا توجد عناصر هنا بعد.</div>
      ) : (
        <div className={view === "grid" ? "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" : "flex flex-col gap-2.5"}>
          {items.map((it) => (
            <ItemCard key={it.id} item={it} view={view} />
          ))}
        </div>
      )}
    </div>
  );
}