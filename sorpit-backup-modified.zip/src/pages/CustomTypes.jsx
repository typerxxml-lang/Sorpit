import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import { Plus, Boxes, Pencil, Trash2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import CustomTypeEditor from "@/components/CustomTypeEditor";
import EmptyState from "@/components/EmptyState";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";

export default function CustomTypes() {
  const { items, loading } = useCollection(
    () => base44.entities.CustomType.filter({}, { sort: "-created_date", limit: 100 })
  );
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const remove = async (t) => {
    try {
      await base44.entities.CustomType.delete(t.id);
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="الأنواع المخصصة"
        subtitle="عرّف أنواع عناصرك وحقولها"
        action={
          <button onClick={() => { setEditing(null); setOpen(true); }} className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <Plus className="h-5 w-5" /> جديد
          </button>
        }
      />
      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا أنواع مخصصة" description="أنشئ نوعًا بحقول خاصة بك." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {items.map((t) => (
            <div key={t.id} className="glass flex flex-col rounded-3xl p-4">
              <div className="glass-soft mb-3 flex h-12 w-12 items-center justify-center rounded-2xl">
                <Boxes className="h-6 w-6" style={t.color ? { color: `hsl(${t.color})` } : { color: "hsl(var(--accent))" }} />
              </div>
              <p className="font-bold leading-tight">{t.name}</p>
              {t.description && <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{t.description}</p>}
              <p className="mt-2 text-[11px] text-muted-foreground">{(t.fields || []).length} حقل · {t.default_view}</p>
              <div className="mt-3 flex gap-1">
                <button onClick={() => { setEditing(t); setOpen(true); }} type="button" className="glass-soft flex flex-1 items-center justify-center gap-1 rounded-xl py-2 text-xs font-bold"><Pencil className="h-3.5 w-3.5" /> تعديل</button>
                <button onClick={() => remove(t)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Trash2 className="h-4 w-4 text-destructive" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      <CustomTypeEditor open={open} onOpenChange={setOpen} ctype={editing} />
    </div>
  );
}