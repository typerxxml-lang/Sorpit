import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { base44 } from "@/api/base44Client";
import { useAuth } from "@/lib/AuthContext";
import { useTheme, ACCENTS } from "@/lib/theme";
import { useFileUrl } from "@/lib/useFileUrl";
import { toast } from "@/components/ui/use-toast";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Loader2, Upload, LogOut, Download, Moon, Sun, FileText, Shield, User, Palette, Database } from "lucide-react";

const TABS = [
  { key: "account", label: "الحساب", icon: User },
  { key: "appearance", label: "المظهر", icon: Palette },
  { key: "data", label: "البيانات", icon: Database },
  { key: "legal", label: "قانوني", icon: Shield },
];

export default function Settings() {
  const navigate = useNavigate();
  const { user, logout, checkUserAuth } = useAuth();
  const { theme, setTheme, accent, setAccent, density, setDensity, reduceMotion, setReduceMotion } = useTheme();
  const [tab, setTab] = useState("account");

  const [displayName, setDisplayName] = useState(user?.data?.display_name || "");
  const [bio, setBio] = useState(user?.data?.bio || "");
  const [saving, setSaving] = useState(false);
  const [uploadingAvatar, setUploadingAvatar] = useState(false);
  const avatarUri = user?.data?.avatar_uri;
  const { url: avatarUrl } = useFileUrl(avatarUri);
  const [exporting, setExporting] = useState(false);

  const saveProfile = async () => {
    setSaving(true);
    try {
      await base44.auth.updateMe({ display_name: displayName.trim(), bio });
      await checkUserAuth();
      toast({ title: "تم حفظ الملف الشخصي" });
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const onAvatar = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadingAvatar(true);
    try {
      const res = await base44.integrations.Core.UploadPrivateFile({ file });
      await base44.auth.updateMe({ avatar_uri: res.file_uri });
      await checkUserAuth();
      toast({ title: "تم تحديث الصورة الشخصية" });
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setUploadingAvatar(false);
    }
  };

  const doLogout = () => {
    base44.auth.logout();
  };

  const exportData = async () => {
    setExporting(true);
    try {
      const allItems = [];
      let cursor;
      let page;
      do {
        page = await base44.entities.Item.filter({}, { sort: "-created_date", limit: 500, cursor });
        allItems.push(...(page.items || []));
        cursor = page.next_cursor;
      } while (cursor && page.has_more);

      const projects = await base44.entities.Project.filter({}, { sort: "-created_date", limit: 500 });
      const folders = await base44.entities.Folder.filter({}, { sort: "-created_date", limit: 500 });

      const payload = {
        exported_at: new Date().toISOString(),
        app: "Sorpit",
        user: { display_name: displayName, email: user?.email },
        projects: projects.items || [],
        folders: folders.items || [],
        items: allItems,
      };
      const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `sorpit-export-${Date.now()}.json`;
      a.click();
      URL.revokeObjectURL(url);
      toast({ title: "تم تصدير بياناتك" });
    } catch (err) {
      toast({ title: "خطأ في التصدير", description: err.message, variant: "destructive" });
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="animate-fade-up">
      <h1 className="mb-5 text-2xl font-extrabold">الإعدادات</h1>

      <div className="no-scrollbar mb-5 flex gap-2 overflow-x-auto pb-1">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex shrink-0 items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold transition ${tab === t.key ? "glass-pill" : "glass-soft text-muted-foreground"}`}
            >
              <Icon className="h-4 w-4" /> {t.label}
            </button>
          );
        })}
      </div>

      {tab === "account" && (
        <div className="space-y-4">
          <div className="glass rounded-3xl p-5">
            <div className="flex items-center gap-4">
              <div className="glass-soft relative h-20 w-20 overflow-hidden rounded-3xl">
                {avatarUrl ? (
                  <img src={avatarUrl} alt="avatar" className="h-full w-full object-cover" />
                ) : (
                  <div className="flex h-full w-full items-center justify-center text-2xl font-bold" style={{ color: "hsl(var(--accent))" }}>
                    {(displayName || user?.email || "S").charAt(0).toUpperCase()}
                  </div>
                )}
              </div>
              <label className="glass-soft flex cursor-pointer items-center gap-2 rounded-2xl px-4 py-2.5 text-sm font-bold transition active:scale-95">
                {uploadingAvatar ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
                تغيير الصورة
                <input type="file" accept="image/*" className="hidden" onChange={onAvatar} disabled={uploadingAvatar} />
              </label>
            </div>
          </div>

          <div className="glass space-y-4 rounded-3xl p-5">
            <div className="space-y-2">
              <Label>اللقب / اسم العرض</Label>
              <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="h-11 rounded-xl" placeholder="اسمك الظاهر" />
            </div>
            <div className="space-y-2">
              <Label>النبذة</Label>
              <Textarea value={bio} onChange={(e) => setBio(e.target.value)} className="min-h-[80px] rounded-xl" placeholder="نبذة قصيرة عنك" />
            </div>
            <div className="space-y-2">
              <Label>البريد الإلكتروني</Label>
              <Input value={user?.email || ""} disabled className="h-11 rounded-xl opacity-60" />
            </div>
            <Button onClick={saveProfile} disabled={saving} className="rounded-xl">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "حفظ التغييرات"}
            </Button>
          </div>

          <div className="glass rounded-3xl p-5">
            <p className="mb-1 text-sm font-bold">تغيير كلمة المرور</p>
            <p className="mb-3 text-xs text-muted-foreground">يتم عبر صفحة استعادة كلمة المرور بالبريد الإلكتروني.</p>
            <Button variant="outline" className="rounded-xl" onClick={() => navigate("/forgot-password")}>
              استعادة كلمة المرور
            </Button>
          </div>

          <div className="glass rounded-3xl p-5">
            <p className="mb-1 text-sm font-bold">تسجيل الخروج</p>
            <p className="mb-3 text-xs text-muted-foreground">يمكنك الدخول مجددًا بنفس الحساب أو حساب آخر.</p>
            <Button variant="outline" className="rounded-xl" onClick={doLogout}>
              <LogOut className="h-4 w-4" /> تسجيل الخروج
            </Button>
          </div>

          <div className="glass rounded-3xl p-5">
            <p className="mb-1 text-sm font-bold text-destructive">حذف الحساب</p>
            <p className="text-xs text-muted-foreground">
              لا تتوفر حاليًا إمكانية حذف الحساب ذاتيًا من داخل التطبيق. للطلب، تواصل مع الدعم. يمكنك تصدير بياناتك أولًا من تبويب «البيانات».
            </p>
          </div>
        </div>
      )}

      {tab === "appearance" && (
        <div className="space-y-4">
          <div className="glass rounded-3xl p-5">
            <p className="mb-3 text-sm font-bold">الوضع</p>
            <div className="flex gap-2">
              <button
                onClick={() => setTheme("dark")}
                className={`flex flex-1 items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold transition ${theme === "dark" ? "glass-pill" : "glass-soft"}`}
              >
                <Moon className="h-4 w-4" /> داكن
              </button>
              <button
                onClick={() => setTheme("light")}
                className={`flex flex-1 items-center justify-center gap-2 rounded-2xl py-3 text-sm font-bold transition ${theme === "light" ? "glass-pill" : "glass-soft"}`}
              >
                <Sun className="h-4 w-4" /> فاتح
              </button>
            </div>
          </div>

          <div className="glass rounded-3xl p-5">
            <p className="mb-3 text-sm font-bold">اللون المميز</p>
            <div className="flex flex-wrap gap-3">
              {Object.entries(ACCENTS).map(([k, v]) => (
                <button
                  key={k}
                  onClick={() => setAccent(k)}
                  className={`h-11 w-11 rounded-full border-2 transition ${accent === k ? "border-foreground scale-110" : "border-transparent"}`}
                  style={{ background: `hsl(${v})` }}
                  aria-label={k}
                />
              ))}
            </div>
          </div>

          <div className="glass rounded-3xl p-5">
            <p className="mb-3 text-sm font-bold">كثافة العرض</p>
            <div className="flex gap-2">
              {[
                { k: "comfortable", l: "مريح" },
                { k: "balanced", l: "متوازن" },
                { k: "compact", l: "مضغوط" },
              ].map((d) => (
                <button
                  key={d.k}
                  onClick={() => setDensity(d.k)}
                  className={`flex-1 rounded-2xl py-3 text-sm font-bold transition ${density === d.k ? "glass-pill" : "glass-soft"}`}
                >
                  {d.l}
                </button>
              ))}
            </div>
          </div>

          <div className="glass flex items-center justify-between rounded-3xl p-5">
            <div>
              <p className="text-sm font-bold">تقليل الحركة</p>
              <p className="text-xs text-muted-foreground">تجربة أكثر هدوءًا دون تأثيرات حركية.</p>
            </div>
            <Switch checked={reduceMotion} onCheckedChange={setReduceMotion} />
          </div>
        </div>
      )}

      {tab === "data" && (
        <div className="space-y-4">
          <div className="glass rounded-3xl p-5">
            <p className="mb-1 text-sm font-bold">تصدير بياناتك</p>
            <p className="mb-3 text-xs text-muted-foreground">
              نزّل نسخة من مشاريعك ومجلداتك وعناصرك في ملف JSON منظم. الملفات المرفقة نفسها لا تُضمّ في التصدير لأسباب تقنية.
            </p>
            <Button onClick={exportData} disabled={exporting} className="rounded-xl">
              {exporting ? <Loader2 className="h-4 w-4 animate-spin" /> : <Download className="h-4 w-4" />}
              تصدير JSON
            </Button>
          </div>
          <div className="glass rounded-3xl p-5">
            <p className="mb-1 text-sm font-bold">حدود التخزين</p>
            <p className="text-xs text-muted-foreground">
              يعمل التطبيق ضمن حدود المنصة الفعلية للتخزين وعدد السجلات. لا يوجد تخزين غير محدود. الملفات تُخزَّن بشكل خاص مرتبط بحسابك.
            </p>
          </div>
        </div>
      )}

      {tab === "legal" && (
        <div className="space-y-3">
          <button onClick={() => navigate("/terms")} className="glass flex w-full items-center justify-between rounded-3xl p-5 text-right transition active:scale-[0.99]">
            <span className="flex items-center gap-3 font-bold"><FileText className="h-5 w-5" /> الشروط والأحكام</span>
            <span className="text-muted-foreground">←</span>
          </button>
          <button onClick={() => navigate("/privacy")} className="glass flex w-full items-center justify-between rounded-3xl p-5 text-right transition active:scale-[0.99]">
            <span className="flex items-center gap-3 font-bold"><Shield className="h-5 w-5" /> سياسة الخصوصية</span>
            <span className="text-muted-foreground">←</span>
          </button>
        </div>
      )}
    </div>
  );
}