import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import { Compass, Sparkles, FolderKanban, StickyNote, Link2, Image as ImageIcon, FileText } from "lucide-react";
import PageHeader from "@/components/PageHeader";

const IDEAS = [
  { icon: FolderKanban, title: "مشروع تعلم جديد", desc: "اجمع مصادرك وملاحظاتك في مشروع واحد." },
  { icon: StickyNote, title: "ملاحظة سريعة", desc: "دوّن فكرة قبل أن تنساها." },
  { icon: Link2, title: "مكتبة روابط", desc: "احفظ الروابط المفيدة منظمة بوسوم." },
  { icon: ImageIcon, title: "ألبوم إلهام", desc: "اجمع الصور التي تلهمك في مجلد." },
  { icon: FileText, title: "ملفات مهمة", desc: "ارفع مستنداتك للوصول إليها من أي مكان." },
  { icon: Sparkles, title: "قالب متكرر", desc: "حوّل مهمة متكررة إلىقالب قابل للتطبيق." },
];

export default function Explore() {
  const { items } = useCollection(
    () => base44.entities.Item.filter({ deleted_at: { $exists: false } }, { sort: "-created_date", limit: 6 })
  );

  return (
    <div className="animate-fade-up">
      <PageHeader title="الاستكشاف" subtitle="أفكار وأحدث ما في مساحتك" />
      <div className="mb-6">
        <p className="mb-3 flex items-center gap-2 text-sm font-bold"><Compass className="h-4 w-4" style={{ color: "hsl(var(--accent))" }} /> أفكار للتنظيم</p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {IDEAS.map((idea, i) => {
            const Icon = idea.icon;
            return (
              <div key={i} className="glass rounded-3xl p-4">
                <div className="glass-soft mb-3 flex h-11 w-11 items-center justify-center rounded-2xl">
                  <Icon className="h-5 w-5" style={{ color: "hsl(var(--accent))" }} />
                </div>
                <p className="text-sm font-bold leading-tight">{idea.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">{idea.desc}</p>
              </div>
            );
          })}
        </div>
      </div>
      <div>
        <p className="mb-3 text-sm font-bold">أحدث عناصرك</p>
        {items.length === 0 ? (
          <p className="text-sm text-muted-foreground">لا عناصر بعد.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {items.map((it) => (
              <div key={it.id} className="glass rounded-3xl p-4">
                <p className="text-sm font-bold leading-tight">{it.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">{it.type}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}