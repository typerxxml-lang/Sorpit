import { useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Copy, Check, Share2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { logActivity } from "@/lib/activityLog";

const EXPIRY = [
  { value: "1", label: "يوم واحد" },
  { value: "7", label: "أسبوع" },
  { value: "30", label: "شهر" },
  { value: "never", label: "بلا انتهاء" },
];

export default function ShareDialog({ open, onOpenChange, item }) {
  const [days, setDays] = useState("7");
  const [busy, setBusy] = useState(false);
  const [link, setLink] = useState("");
  const [copied, setCopied] = useState(false);

  const create = async () => {
    if (!item) return;
    setBusy(true);
    try {
      const token = crypto.randomUUID();
      let expires_at = "";
      if (days !== "never") {
        const d = new Date();
        d.setDate(d.getDate() + parseInt(days, 10));
        expires_at = d.toISOString();
      }
      await base44.entities.ShareLink.create({ item_id: item.id, token, expires_at, is_active: true });
      await logActivity("share", `مشاركة: ${item.title}`, { entity_type: "Item", entity_id: item.id });
      setLink(`${window.location.origin}/share/${token}`);
      toast({ title: "تم إنشاء رابط المشاركة" });
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(link);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch (e) {
      toast({ title: "تعذّر النسخ", variant: "destructive" });
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass rounded-[2rem] p-0 sm:max-w-md">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle className="flex items-center gap-2"><Share2 className="h-5 w-5" style={{ color: "hsl(var(--accent))" }} /> مشاركة العنصر</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 px-6 py-4">
          {!link ? (
            <>
              <div className="glass-soft rounded-2xl px-4 py-3 text-sm">
                <p className="font-bold">{item?.title}</p>
                <p className="text-xs text-muted-foreground">سيُنشأ رابط عام يتيح لأي شخص يملكه الاطلاع على هذا العنصر حتى انتهاء صلاحيته.</p>
              </div>
              <div className="space-y-2">
                <Label>صلاحية الرابط</Label>
                <Select value={days} onValueChange={setDays}>
                  <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>{EXPIRY.map((e) => <SelectItem key={e.value} value={e.value}>{e.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            </>
          ) : (
            <div className="space-y-2">
              <Label>رابط المشاركة</Label>
              <div className="flex gap-2">
                <Input dir="ltr" readOnly value={link} className="h-11 rounded-xl text-left" />
                <Button onClick={copy} className="rounded-xl">{copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}</Button>
              </div>
              <p className="text-xs text-muted-foreground">انسخ الرابط وشاركه. يبطل تلقائيًا عند انتهاء الصلاحية.</p>
            </div>
          )}
        </div>
        <div className="glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => { setLink(""); onOpenChange(false); }} className="rounded-xl">إغلاق</Button>
            {!link && (
              <Button onClick={create} disabled={busy} className="rounded-xl">
                {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "إنشاء الرابط"}
              </Button>
            )}
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}