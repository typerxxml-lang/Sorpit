import { useNavigate } from "react-router-dom";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  CheckSquare,
  Folder,
  Boxes,
  LayoutTemplate,
  Zap,
  Compass,
  Archive,
  Trash2,
  History,
  Code2,
} from "lucide-react";

const LINKS = [
  { label: "المهام", icon: CheckSquare, path: "/app/tasks" },
  { label: "المجلدات", icon: Folder, path: "/app/folders" },
  { label: "الأنواع المخصصة", icon: Boxes, path: "/app/custom-types" },
  { label: "القوالب", icon: LayoutTemplate, path: "/app/templates" },
  { label: "الأتمتة", icon: Zap, path: "/app/automations" },
  { label: "الإشعارات", icon: History, path: "/app/notifications" },
  { label: "سجل النشاط", icon: History, path: "/app/activity" },
  { label: "الاستكشاف", icon: Compass, path: "/app/explore" },
  { label: "الأرشيف", icon: Archive, path: "/app/archive" },
  { label: "السلة", icon: Trash2, path: "/app/trash" },
  { label: "وضع المطور", icon: Code2, path: "/app/developer" },
];

export default function MoreMenu({ open, onOpenChange }) {
  const navigate = useNavigate();
  const go = (path) => {
    onOpenChange(false);
    navigate(path);
  };
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass rounded-[2rem] p-0 sm:max-w-md">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle className="text-lg">المزيد</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-3 gap-3 p-6">
          {LINKS.map((l) => {
            const Icon = l.icon;
            return (
              <button
                key={l.path}
                onClick={() => go(l.path)}
                className="glass-soft flex flex-col items-center gap-2 rounded-2xl px-2 py-4 text-center transition active:scale-95"
                type="button"
              >
                <Icon className="h-6 w-6" style={{ color: "hsl(var(--accent))" }} />
                <span className="text-xs font-bold leading-tight">{l.label}</span>
              </button>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}