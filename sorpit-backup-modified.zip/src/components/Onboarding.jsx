import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/lib/AuthContext";
import { base44 } from "@/api/base44Client";
import BrandLogo from "@/components/BrandLogo";
import { Button } from "@/components/ui/button";
import { ArrowLeft, FolderKanban, StickyNote, Image as ImageIcon, Link2, Check } from "lucide-react";

const STEPS = [
  { icon: FolderKanban, title: "أنشئ مشاريعك", desc: "اجمع كل ما يخص هدفًا واحدًا في مشروع منظم." },
  { icon: StickyNote, title: "دوّن وارفع", desc: "ملاحظات وصور وملفات وروابط في مكان واحد." },
  { icon: Link2, title: "شارك بأمان", desc: "أنشئ روابط مشاركة مؤقتة لأي عنصر." },
  { icon: Check, title: "جاهز للبدء", desc: "كل عالمك الرقمي الآن بين يديك." },
];

export default function Onboarding() {
  const { user, checkUserAuth } = useAuth();
  const [step, setStep] = useState(0);
  const [finishing, setFinishing] = useState(false);
  const [done, setDone] = useState(false);
  const ONB_KEY = "sorpit-onboarding-done";

  if (user?.data?.onboarding_done || done || localStorage.getItem(ONB_KEY)) return null;

  const finish = async () => {
    setFinishing(true);
    try { localStorage.setItem(ONB_KEY, "1"); } catch (e) { /* ignore */ }
    setDone(true);
    try {
      await base44.auth.updateMe({ onboarding_done: true });
    } catch (e) { /* server persist best-effort */ }
  };

  const SIcon = STEPS[step].icon;
  const last = step === STEPS.length - 1;

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center px-6 text-center">
      <div className="relative z-10 w-full max-w-sm">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={step}
            initial={{ opacity: 0, x: -34, scale: 0.97 }}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            exit={{ opacity: 0, x: 34, scale: 0.97 }}
            transition={{ duration: 0.32, ease: [0.22, 1, 0.36, 1] }}
            className="glass rounded-[2rem] p-8"
          >
            <motion.div
              key={"i" + step}
              initial={{ scale: 0.4, rotate: -14, opacity: 0 }}
              animate={{ scale: 1, rotate: 0, opacity: 1 }}
              transition={{ type: "spring", stiffness: 220, damping: 14, delay: 0.08 }}
              className="glass-soft mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-3xl"
            >
              {step === 0 ? <BrandLogo size={40} className="mx-auto" /> : <SIcon className="h-8 w-8" style={{ color: "hsl(var(--accent))" }} />}
            </motion.div>
            <h1 className="text-xl font-extrabold">{STEPS[step].title}</h1>
            <p className="mt-2 text-sm text-muted-foreground">{STEPS[step].desc}</p>
            <div className="mt-6 flex justify-center gap-1.5">
              {STEPS.map((_, i) => (
                <motion.span
                  key={i}
                  className="h-1.5 rounded-full"
                  style={{ background: "hsl(var(--accent))" }}
                  animate={{ width: i === step ? 22 : 8, opacity: i === step ? 1 : 0.25 }}
                  transition={{ type: "spring", stiffness: 300, damping: 24 }}
                />
              ))}
            </div>
          </motion.div>
        </AnimatePresence>

        <div className="mt-5 flex gap-2">
          <Button variant="ghost" onClick={finish} disabled={finishing} className="flex-1 rounded-2xl">تخطٍّ</Button>
          <Button onClick={() => (last ? finish() : setStep((s) => s + 1))} disabled={finishing} className="glass-pill flex-[2] rounded-2xl">
            {last ? "ابدأ الآن" : "التالي"}
            <ArrowLeft className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}