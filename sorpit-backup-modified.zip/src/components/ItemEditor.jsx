import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Loader2, Upload, Star, FolderPlus, Download, ExternalLink, Share2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useFileUrl } from "@/lib/useFileUrl";
import { TYPE_META, formatBytes } from "@/lib/itemHelpers";
import { ACCENTS } from "@/lib/theme";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { useFileUrl as useSigned } from "@/lib/useFileUrl";
import ReactQuill from "react-quill-new";
import "react-quill-new/dist/quill.snow.css";
import ShareDialog from "@/components/ShareDialog";

const COLOR_CHOICES = Object.entries(ACCENTS);

export default function ItemEditor({
  open,
  onOpenChange,
  type,
  item,
  presetProjectId,
  presetFolderId,
}) {
  const isEdit = !!item;
  const realType = item?.type || type;
  const meta = TYPE_META[realType] || TYPE_META.note;

  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [projects, setProjects] = useState([]);
  const [folders, setFolders] = useState([]);
  const [newFolder, setNewFolder] = useState("");
  const [showNewFolder, setShowNewFolder] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);

  const fileUri = form.file_uri || item?.file_uri;
  const { url: previewUrl } = useSigned(realType === "image" ? fileUri : null);
  const { url: downloadUrl } = useFileUrl(realType === "file" ? fileUri : null);

  useEffect(() => {
    if (!open) return;
    if (item) {
      setForm({ ...item, tagsStr: (item.tags || []).join("، ") });
    } else {
      setForm({
        title: "",
        description: "",
        content: "",
        file_uri: "",
        file_name: "",
        file_type: "",
        file_size: 0,
        url: "",
        tagsStr: "",
        project_id: presetProjectId || "",
        folder_id: presetFolderId || "",
        color: "",
        is_favorite: false,
      });
    }
  }, [open, item, presetProjectId, presetFolderId]);

  useEffect(() => {
    if (!open) return;
    base44.entities.Project
      .filter(
        { deleted_at: { $exists: false }, is_archived: { $ne: true } },
        { sort: "-created_date", limit: 100, fields: ["name"] }
      )
      .then((res) => setProjects(res.items || []))
      .catch(() => {});
    base44.entities.Folder
      .filter(
        { deleted_at: { $exists: false }, is_archived: { $ne: true } },
        { sort: "-created_date", limit: 100, fields: ["name", "color"] }
      )
      .then((res) => setFolders(res.items || []))
      .catch(() => {});
  }, [open]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const onFile = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      const res = await base44.integrations.Core.UploadPrivateFile({ file });
      set("file_uri", res.file_uri);
      set("file_name", file.name);
      set("file_type", file.type);
      set("file_size", file.size);
      if (!form.title && !item?.title) set("title", file.name.replace(/\.[^.]+$/, ""));
    } catch (err) {
      toast({ title: "فشل رفع الملف", description: err.message, variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  const createFolderInline = async () => {
    if (!newFolder.trim()) return;
    try {
      const f = await base44.entities.Folder.create({ name: newFolder.trim(), color: "250 82% 72%" });
      setFolders((prev) => [...prev, f]);
      set("folder_id", f.id);
      setNewFolder("");
      setShowNewFolder(false);
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    }
  };

  const save = async () => {
    if (!form.title?.trim() && !item?.title) {
      toast({ title: "العنوان مطلوب", variant: "destructive" });
      return;
    }
    if ((realType === "image" || realType === "file") && !fileUri) {
      toast({ title: "الملف مطلوب", variant: "destructive" });
      return;
    }
    if (realType === "link" && !(form.url || item?.url)?.trim()) {
      toast({ title: "الرابط مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const tagsArr = (form.tagsStr || "")
        .split(/[،,]/)
        .map((s) => s.trim())
        .filter(Boolean);
      const payload = {
        type: realType,
        title: (form.title || item?.title || "").trim(),
        description: form.description ?? item?.description ?? "",
        content: realType === "note" ? (form.content ?? item?.content ?? "") : (item?.content || ""),
        file_uri: fileUri || "",
        file_name: form.file_name || item?.file_name || "",
        file_type: form.file_type || item?.file_type || "",
        file_size: form.file_size || item?.file_size || 0,
        url: realType === "link" ? (form.url || "") : (item?.url || ""),
        tags: tagsArr,
        category: form.category || item?.category || "",
        project_id: form.project_id || item?.project_id || "",
        folder_id: form.folder_id || item?.folder_id || "",
        color: form.color || item?.color || "",
        is_favorite: form.is_favorite ?? item?.is_favorite ?? false,
      };
      if (isEdit) {
        await base44.entities.Item.update(item.id, payload);
      } else {
        await base44.entities.Item.create(payload);
      }
      toast({ title: isEdit ? "تم الحفظ" : "تم الإنشاء بنجاح" });
      emitDataChanged();
      onOpenChange(false);
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-h-[92vh] overflow-y-auto rounded-[2rem] p-0 sm:max-w-lg">
        <div className="sticky top-0 z-10 glass rounded-t-[2rem] px-6 py-4">
          <DialogHeader className="text-right">
            <DialogTitle className="flex items-center gap-2">
              <span style={{ color: "hsl(var(--accent))" }}>
                {(() => {
                  const Icon = meta.icon;
                  return <Icon className="h-5 w-5" />;
                })()}
              </span>
              {isEdit ? "تعديل العنصر" : `${meta.label} جديد`}
            </DialogTitle>
          </DialogHeader>
        </div>

        <div className="space-y-5 px-6 py-5">
          {/* image / file upload */}
          {(realType === "image" || realType === "file") && (
            <div className="space-y-2">
              <Label>الملف</Label>
              {realType === "image" && previewUrl && (
                <div className="glass-soft overflow-hidden rounded-2xl">
                  <img src={previewUrl} alt={form.title} className="max-h-64 w-full object-contain" />
                </div>
              )}
              {fileUri && realType === "file" && (
                <div className="glass-soft flex items-center justify-between rounded-2xl px-4 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{form.file_name || item?.file_name}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatBytes(form.file_size || item?.file_size)}
                    </p>
                  </div>
                  {downloadUrl && (
                    <a
                      href={downloadUrl}
                      download={form.file_name || item?.file_name}
                      className="glass-soft flex h-9 w-9 items-center justify-center rounded-xl"
                    >
                      <Download className="h-4 w-4" />
                    </a>
                  )}
                </div>
              )}
              <label className="glass-soft flex cursor-pointer items-center justify-center gap-2 rounded-2xl py-3 text-sm font-medium transition active:scale-[0.98]">
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" /> جارٍ الرفع…
                  </>
                ) : (
                  <>
                    <Upload className="h-4 w-4" />
                    {fileUri ? "استبدال الملف" : "اختيار ملف"}
                  </>
                )}
                <input
                  type="file"
                  className="hidden"
                  onChange={onFile}
                  accept={realType === "image" ? "image/*" : undefined}
                  disabled={uploading}
                />
              </label>
            </div>
          )}

          {/* link url */}
          {realType === "link" && (
            <div className="space-y-2">
              <Label>الرابط</Label>
              <Input
                dir="ltr"
                value={form.url ?? item?.url ?? ""}
                onChange={(e) => set("url", e.target.value)}
                placeholder="https://example.com"
                className="h-11 rounded-xl text-left"
              />
              {(form.url || item?.url) && (
                <a
                  href={form.url || item?.url}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1 text-xs"
                  style={{ color: "hsl(var(--accent))" }}
                >
                  <ExternalLink className="h-3 w-3" /> فتح الرابط
                </a>
              )}
            </div>
          )}

          {/* title */}
          <div className="space-y-2">
            <Label>العنوان</Label>
            <Input
              value={form.title ?? item?.title ?? ""}
              onChange={(e) => set("title", e.target.value)}
              placeholder="عنوان العنصر"
              className="h-11 rounded-xl"
            />
          </div>

          {/* description */}
          <div className="space-y-2">
            <Label>الوصف</Label>
            <Textarea
              value={form.description ?? item?.description ?? ""}
              onChange={(e) => set("description", e.target.value)}
              placeholder="وصف اختياري"
              className="min-h-[70px] rounded-xl"
            />
          </div>

          {/* note content */}
          {realType === "note" && (
            <div className="space-y-2">
              <Label>المحتوى</Label>
              <div className="glass-soft overflow-hidden rounded-xl">
                <ReactQuill
                  theme="snow"
                  value={form.content ?? item?.content ?? ""}
                  onChange={(v) => set("content", v)}
                  modules={{
                    toolbar: [["bold", "italic", "underline"], [{ list: "bullet" }, { list: "ordered" }], ["link"], ["clean"]],
                  }}
                  placeholder="اكتب ملاحظتك هنا…"
                />
              </div>
            </div>
          )}

          {/* project + folder */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>المشروع</Label>
              <Select
                value={form.project_id ?? item?.project_id ?? ""}
                onValueChange={(v) => set("project_id", v === "none" ? "" : v)}
              >
                <SelectTrigger className="h-11 rounded-xl">
                  <SelectValue placeholder="بدون مشروع" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون مشروع</SelectItem>
                  {projects.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>المجلد</Label>
              <Select
                value={form.folder_id ?? item?.folder_id ?? ""}
                onValueChange={(v) => set("folder_id", v === "none" ? "" : v)}
              >
                <SelectTrigger className="h-11 rounded-xl">
                  <SelectValue placeholder="بدون مجلد" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون مجلد</SelectItem>
                  {folders.map((f) => (
                    <SelectItem key={f.id} value={f.id}>
                      {f.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* inline new folder */}
          <div className="space-y-2">
            {showNewFolder ? (
              <div className="flex gap-2">
                <Input
                  value={newFolder}
                  onChange={(e) => setNewFolder(e.target.value)}
                  placeholder="اسم المجلد الجديد"
                  className="h-10 rounded-xl"
                />
                <Button type="button" size="sm" onClick={createFolderInline} className="rounded-xl">
                  حفظ
                </Button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setShowNewFolder(true)}
                className="inline-flex items-center gap-1.5 text-xs font-medium"
                style={{ color: "hsl(var(--accent))" }}
              >
                <FolderPlus className="h-3.5 w-3.5" /> إنشاء مجلد جديد
              </button>
            )}
          </div>

          {/* tags */}
          <div className="space-y-2">
            <Label>الوسوم</Label>
            <Input
              value={form.tagsStr ?? ""}
              onChange={(e) => set("tagsStr", e.target.value)}
              placeholder="افصل بين الوسوم بفاصلة"
              className="h-11 rounded-xl"
            />
          </div>

          {/* color */}
          <div className="space-y-2">
            <Label>اللون المميز</Label>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => set("color", "")}
                className={`h-8 w-8 rounded-full border-2 ${!form.color ? "border-foreground" : "border-transparent"}`}
                style={{ background: "hsl(var(--muted))" }}
                aria-label="بدون"
              />
              {COLOR_CHOICES.map(([k, v]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => set("color", v)}
                  className={`h-8 w-8 rounded-full border-2 ${(form.color || item?.color) === v ? "border-foreground" : "border-transparent"}`}
                  style={{ background: `hsl(${v})` }}
                  aria-label={k}
                />
              ))}
            </div>
          </div>

          {/* favorite */}
          <div className="flex items-center justify-between rounded-2xl glass-soft px-4 py-3">
            <Label className="flex items-center gap-2">
              <Star className="h-4 w-4" /> إضافة للمفضلة
            </Label>
            <Switch
              checked={!!(form.is_favorite ?? item?.is_favorite)}
              onCheckedChange={(v) => set("is_favorite", v)}
            />
          </div>
        </div>

        <div className="sticky bottom-0 glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            {isEdit && (
              <Button variant="outline" onClick={() => setShareOpen(true)} className="rounded-xl">
                <Share2 className="h-4 w-4" /> مشاركة
              </Button>
            )}
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">
              إلغاء
            </Button>
            <Button onClick={save} disabled={saving || uploading} className="rounded-xl">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ التعديلات" : "إنشاء"}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
      <ShareDialog open={shareOpen} onOpenChange={setShareOpen} item={item} />
    </Dialog>
  );
}