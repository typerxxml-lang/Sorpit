import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { MoreVertical, Archive, Trash2, Pencil, RotateCcw } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { PROJECT_STATUS, timeAgo } from "@/lib/itemHelpers";
import { base44 } from "@/api/base44Client";
import { emitDataChanged } from "@/lib/dataEvents";
import { toast } from "@/components/ui/use-toast";

export default function ProjectCard({ project, onEdit }) {
  const navigate = useNavigate();
  const status = PROJECT_STATUS[project.status] || PROJECT_STATUS.new;
  const StatusIcon = status.icon;
  const accent = project.cover_color || "250 82% 72%";
  const [busy, setBusy] = useState(false);

  const act = async (fn, msg) => {
    setBusy(true);
    try {
      await fn();
      emitDataChanged();
      if (msg) toast({ title: msg });
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      onClick={() => navigate(`/app/projects/${project.id}`)}
      className="glass-soft group relative cursor-pointer overflow-hidden rounded-3xl p-4 transition active:scale-[0.98]"
    >
      <div
        className="absolute inset-x-0 top-0 h-1.5"
        style={{ background: `hsl(${accent})` }}
      />
      <div className="flex items-start justify-between gap-2 pt-1">
        <div className="min-w-0">
          <h3 className="truncate text-base font-bold">{project.name}</h3>
          {project.description && (
            <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{project.description}</p>
          )}
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              onClick={(e) => e.stopPropagation()}
              className="glass-soft flex h-8 w-8 shrink-0 items-center justify-center rounded-lg opacity-70 transition active:scale-90"
              aria-label="إجراءات"
            >
              <MoreVertical className="h-4 w-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" className="glass rounded-2xl">
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                onEdit?.(project);
              }}
            >
              <Pencil className="h-4 w-4" /> تعديل
            </DropdownMenuItem>
            <DropdownMenuItem
              onClick={(e) => {
                e.stopPropagation();
                act(() => base44.entities.Project.update(project.id, { is_archived: !project.is_archived }), project.is_archived ? "أُلغي الأرشفة" : "أُرشف المشروع");
              }}
            >
              <Archive className="h-4 w-4" /> {project.is_archived ? "إلغاء الأرشفة" : "أرشفة"}
            </DropdownMenuItem>
            <DropdownMenuItem
              className="text-destructive"
              onClick={(e) => {
                e.stopPropagation();
                act(() => base44.entities.Project.update(project.id, { deleted_at: new Date().toISOString() }), "نُقل للسلة");
              }}
            >
              <Trash2 className="h-4 w-4" /> نقل للسلة
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      <div className="mt-4 flex items-center justify-between">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold"
          style={{ background: `hsl(${status.color} / 0.16)`, color: `hsl(${status.color})` }}
        >
          <StatusIcon className="h-3 w-3" /> {status.label}
        </span>
        <span className="text-[10px] text-muted-foreground/70">{timeAgo(project.updated_date || project.created_date)}</span>
      </div>
    </div>
  );
}