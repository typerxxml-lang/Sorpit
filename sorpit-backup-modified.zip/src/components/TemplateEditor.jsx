import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";
import { ACCENTS } from "@/lib/theme";

const TARGETS = [
  { value: "item", label: "عنصر" },
  { value: "project", label: "مشروع" },
  { value: "task", label: "مهمة" },
];
const ITEM_TYPES = [
  { value: "note", label: "نص وملاحظة" },
  { value: "image", label: "صورة" },
  { value: "file", label: "ملف" },
  { value: "link", label: "رابط" },
];

export default function TemplateEditor({ open, onOpenChange, template }) {
  const isEdit = !!template;
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (template) setForm({ ...template, tagsStr: (template.blueprint?.tags || []).join("، ") });
    else setForm({ name: "", description: "", target: "item", item_type: "note", bp_title: "", bp_tagsStr: "", bp_color: "" });
  }, [open, template]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async () => {
    if (!form.name?.trim()) { toast({ title: "الاسم مطلوب", variant: "destructive" }); return; }
    setSaving(true);
    try {
      const tags = (form.bp_tagsStr || "").split(/[،,]/).map((s) => s.trim()).filter(Boolean);
      const blueprint = {
        title: form.bp_title || "",
        tags,
        color: form.bp_color || "",
        item_type: form.item_type || form.target,
      };
      const payload = {
        name: form.name.trim(),
        description: form.description || "",
        target: form.target || "item",
        item_type: form.target === "item" ? form.item_type || "note" : "",
        blueprint,
      };
      if (isEdit) await base44.entities.Template.update(template.id, payload);
      else {
        const c = await base44.entities.Template.create(payload);
        await logActivity("create", `قالب جديد: ${payload.name}`, { entity_type: "Template", entity_id: c.id });
      }
      toast({ title: isEdit ? "تم الحفظ" : "تم إنشاء القالب" });
      emitDataChanged();
      onOpenChange(false);
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-h-[92vh] overflow-y-auto rounded-[2rem] p-0 sm:max-w-md">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle>{isEdit ? "تعديل القالب" : "قالب جديد"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 px-6 py-4">
          <div className="space-y-2">
            <Label>اسم القالب</Label>
            <Input value={form.name ?? ""} onChange={(e) => set("name", e.target.value)} className="h-11 rounded-xl" />
          </div>
          <div className="space-y-2">
            <Label>الوصف</Label>
            <Textarea value={form.description ?? ""} onChange={(e) => set("description", e.target.value)} className="min-h-[60px] rounded-xl" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>الهدف</Label>
              <Select value={form.target ?? "item"} onValueChange={(v) => set("target", v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>{TARGETS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            {form.target === "item" && (
              <div className="space-y-2">
                <Label>نوع العنصر</Label>
                <Select value={form.item_type ?? "note"} onValueChange={(v) => set("item_type", v)}>
                  <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>{ITEM_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
            )}
          </div>
          <div className="space-y-2">
            <Label>عنوان مبدئي</Label>
            <Input value={form.bp_title ?? ""} onChange={(e) => set("bp_title", e.target.value)} className="h-11 rounded-xl" />
          </div>
          <div className="space-y-2">
            <Label>وسوم مبدئية</Label>
            <Input value={form.bp_tagsStr ?? ""} onChange={(e) => set("bp_tagsStr", e.target.value)} className="h-11 rounded-xl" placeholder="افصل بفاصلة" />
          </div>
          <div className="space-y-2">
            <Label>لون مميز</Label>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => set("bp_color", "")} className={`h-8 w-8 rounded-full border-2 ${!form.bp_color ? "border-foreground" : "border-transparent"}`} style={{ background: "hsl(var(--muted))" }} />
              {Object.entries(ACCENTS).map(([k, v]) => (
                <button key={k} type="button" onClick={() => set("bp_color", v)} className={`h-8 w-8 rounded-full border-2 ${form.bp_color === v ? "border-foreground" : "border-transparent"}`} style={{ background: `hsl(${v})` }} />
              ))}
            </div>
          </div>
        </div>
        <div className="sticky bottom-0 glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">إلغاء</Button>
            <Button onClick={save} disabled={saving} className="rounded-xl">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ" : "إنشاء"}</Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}