import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { ACCENTS } from "@/lib/theme";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";

const COLOR_CHOICES = Object.entries(ACCENTS);

export default function FolderEditor({ open, onOpenChange, folder, parent_id }) {
  const isEdit = !!folder;
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setForm({
      name: folder?.name || "",
      color: folder?.color || "250 82% 72%",
      parent_id: folder?.parent_id || parent_id || "",
    });
  }, [open, folder, parent_id]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    if (!(form.name || "").trim()) {
      toast({ title: "اسم المجلد مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload = { name: form.name.trim(), color: form.color, parent_id: form.parent_id || "" };
      if (isEdit) {
        await base44.entities.Folder.update(folder.id, payload);
      } else {
        await base44.entities.Folder.create(payload);
      }
      toast({ title: isEdit ? "تم الحفظ" : "أُنشئ المجلد" });
      emitDataChanged();
      onOpenChange(false);
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass rounded-[2rem] p-0 sm:max-w-sm">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle>{isEdit ? "تعديل المجلد" : "مجلد جديد"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 px-6 py-4">
          <div className="space-y-2">
            <Label>اسم المجلد</Label>
            <Input
              value={form.name || ""}
              onChange={(e) => set("name", e.target.value)}
              className="h-11 rounded-xl"
              placeholder="اسم المجلد"
            />
          </div>
          <div className="space-y-2">
            <Label>اللون</Label>
            <div className="flex flex-wrap gap-2">
              {COLOR_CHOICES.map(([k, v]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => set("color", v)}
                  className={`h-8 w-8 rounded-full border-2 ${form.color === v ? "border-foreground" : "border-transparent"}`}
                  style={{ background: `hsl(${v})` }}
                  aria-label={k}
                />
              ))}
            </div>
          </div>
        </div>
        <div className="px-6 pb-6">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">
              إلغاء
            </Button>
            <Button onClick={save} disabled={saving} className="rounded-xl">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ" : "إنشاء"}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}