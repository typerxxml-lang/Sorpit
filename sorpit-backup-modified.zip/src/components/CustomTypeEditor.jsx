import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, X } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";
import { ACCENTS } from "@/lib/theme";

const FIELD_TYPES = [
  { value: "text", label: "نص" },
  { value: "number", label: "رقم" },
  { value: "date", label: "تاريخ" },
  { value: "boolean", label: "صح/خطأ" },
  { value: "list", label: "قائمة" },
];

export default function CustomTypeEditor({ open, onOpenChange, ctype }) {
  const isEdit = !!ctype;
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [newField, setNewField] = useState({ name: "", type: "text" });

  useEffect(() => {
    if (!open) return;
    if (ctype) setForm({ ...ctype });
    else setForm({ name: "", description: "", icon: "Boxes", color: "", default_view: "grid", fields: [] });
  }, [open, ctype]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const addField = () => {
    if (!newField.name.trim()) return;
    set("fields", [...(form.fields || []), { ...newField, name: newField.name.trim() }]);
    setNewField({ name: "", type: "text" });
  };
  const removeField = (i) => set("fields", (form.fields || []).filter((_, idx) => idx !== i));

  const save = async () => {
    if (!form.name?.trim()) { toast({ title: "الاسم مطلوب", variant: "destructive" }); return; }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        description: form.description || "",
        icon: form.icon || "Boxes",
        color: form.color || "",
        default_view: form.default_view || "grid",
        fields: form.fields || [],
      };
      if (isEdit) await base44.entities.CustomType.update(ctype.id, payload);
      else {
        const c = await base44.entities.CustomType.create(payload);
        await logActivity("create", `نوع مخصص: ${payload.name}`, { entity_type: "CustomType", entity_id: c.id });
      }
      toast({ title: isEdit ? "تم الحفظ" : "تم إنشاء النوع" });
      emitDataChanged();
      onOpenChange(false);
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-h-[92vh] overflow-y-auto rounded-[2rem] p-0 sm:max-w-md">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle>{isEdit ? "تعديل النوع" : "نوع مخصص جديد"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 px-6 py-4">
          <div className="space-y-2">
            <Label>اسم النوع</Label>
            <Input value={form.name ?? ""} onChange={(e) => set("name", e.target.value)} className="h-11 rounded-xl" />
          </div>
          <div className="space-y-2">
            <Label>الوصف</Label>
            <Input value={form.description ?? ""} onChange={(e) => set("description", e.target.value)} className="h-11 rounded-xl" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>طريقة العرض</Label>
              <Select value={form.default_view ?? "grid"} onValueChange={(v) => set("default_view", v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="grid">شبكة</SelectItem>
                  <SelectItem value="list">قائمة</SelectItem>
                  <SelectItem value="gallery">معرض</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>اللون</Label>
              <div className="flex flex-wrap gap-2 pt-1">
                <button type="button" onClick={() => set("color", "")} className={`h-9 w-9 rounded-full border-2 ${!form.color ? "border-foreground" : "border-transparent"}`} style={{ background: "hsl(var(--muted))" }} />
                {Object.entries(ACCENTS).map(([k, v]) => (
                  <button key={k} type="button" onClick={() => set("color", v)} className={`h-9 w-9 rounded-full border-2 ${form.color === v ? "border-foreground" : "border-transparent"}`} style={{ background: `hsl(${v})` }} />
                ))}
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <Label>الحقول</Label>
            <div className="space-y-2">
              {(form.fields || []).map((f, i) => (
                <div key={i} className="glass-soft flex items-center gap-2 rounded-xl px-3 py-2">
                  <span className="flex-1 text-sm font-medium">{f.name}</span>
                  <span className="text-xs text-muted-foreground">{FIELD_TYPES.find((t) => t.value === f.type)?.label}</span>
                  <button onClick={() => removeField(i)} type="button"><X className="h-4 w-4 text-muted-foreground" /></button>
                </div>
              ))}
              <div className="flex gap-2">
                <Input value={newField.name} onChange={(e) => setNewField({ ...newField, name: e.target.value })} placeholder="اسم الحقل" className="h-10 rounded-xl" />
                <Select value={newField.type} onValueChange={(v) => setNewField({ ...newField, type: v })}>
                  <SelectTrigger className="h-10 w-28 rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>{FIELD_TYPES.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
                </Select>
                <Button type="button" size="sm" onClick={addField} className="rounded-xl"><Plus className="h-4 w-4" /></Button>
              </div>
            </div>
          </div>
        </div>
        <div className="sticky bottom-0 glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">إلغاء</Button>
            <Button onClick={save} disabled={saving} className="rounded-xl">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ" : "إنشاء"}</Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}