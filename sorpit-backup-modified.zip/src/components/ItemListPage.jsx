import { useState } from "react";
import { LayoutGrid, List, Plus, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";
import { useCollection } from "@/lib/useCollection";
import ItemCard from "@/components/ItemCard";
import EmptyState from "@/components/EmptyState";
import { useItemEditor } from "@/components/ItemEditorProvider";

export default function ItemListPage({
  title,
  subtitle,
  icon: Icon,
  filter,
  emptyTitle,
  emptyDesc,
  createType,
  createLabel,
}) {
  const { openCreate } = useItemEditor();
  const [view, setView] = useState("grid");
  const filterKey = JSON.stringify(filter);
  const { items, loading } = useCollection(
    () => base44.entities.Item.filter(filter, { sort: "-updated_date", limit: 100 }),
    [filterKey]
  );

  return (
    <div className="animate-fade-up">
      <div className="mb-5 flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          {Icon && (
            <span
              className="glass-soft flex h-11 w-11 items-center justify-center rounded-2xl"
              style={{ color: "hsl(var(--accent))" }}
            >
              <Icon className="h-6 w-6" />
            </span>
          )}
          <div>
            <h1 className="text-xl font-extrabold leading-tight">{title}</h1>
            {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          <div className="glass-soft flex rounded-2xl p-1">
            <button
              onClick={() => setView("grid")}
              className={`flex h-8 w-8 items-center justify-center rounded-xl transition ${view === "grid" ? "glass-pill" : ""}`}
              aria-label="شبكة"
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button
              onClick={() => setView("list")}
              className={`flex h-8 w-8 items-center justify-center rounded-xl transition ${view === "list" ? "glass-pill" : ""}`}
              aria-label="قائمة"
            >
              <List className="h-4 w-4" />
            </button>
          </div>
          {createType && (
            <button
              onClick={() => openCreate(createType)}
              className="glass-pill flex h-10 w-10 items-center justify-center rounded-2xl transition active:scale-90"
              aria-label={createLabel || "جديد"}
            >
              <Plus className="h-5 w-5" />
            </button>
          )}
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-20">
          <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          icon={Icon}
          title={emptyTitle}
          description={emptyDesc}
          action={
            createType && (
              <button
                onClick={() => openCreate(createType)}
                className="glass-pill flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition active:scale-95"
              >
                <Plus className="h-4 w-4" /> {createLabel || "إنشاء"}
              </button>
            )
          }
        />
      ) : (
        <div className={view === "grid" ? "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" : "flex flex-col gap-2.5"}>
          {items.map((it) => (
            <ItemCard key={it.id} item={it} view={view} />
          ))}
        </div>
      )}
    </div>
  );
}