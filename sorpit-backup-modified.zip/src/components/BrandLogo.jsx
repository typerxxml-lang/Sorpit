import { Image } from "@/components/ui/image";

const LOGO_URL =
  "https://media.base44.com/images/public/6ad5627ebb9c27c20f8c37c0/09f6ddd44_file_00000000d0f08208a75f089ead474b48.png";

/**
 * The official Sorpit brand mark (uploaded logo) rendered at a fixed size.
 */
export default function BrandLogo({ size = 88, className = "", round = false }) {
  return (
    <div
      className={`relative shrink-0 ${className}`}
      style={{ width: size, height: size }}
    >
      <Image
        src={LOGO_URL}
        alt="Sorpit"
        fittingType="fit"
        className={`h-full w-full object-contain ${round ? "rounded-full" : ""}`}
      />
    </div>
  );
}