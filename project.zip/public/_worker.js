// Sorpit API — Cloudflare Pages (advanced mode) + قاعدة بيانات D1 (الربط باسم DB)
// حسابات يوزر/كلمة مرور + بيانات المستخدم + الملفات + روابط المشاركة

const ENTITIES = new Set([
  "Project", "Folder", "Item", "Task", "Template",
  "AutomationRule", "CustomType", "ShareLink", "Notification", "ActivityLog",
]);
const MAX_RECORD_BYTES = 1_800_000;
const MAX_CHUNK_CHARS = 800_000;
const MAX_CHUNKS = 40;
const PBKDF2_ITERATIONS = 10000;
const INVALID_LOGIN = "اسم المستخدم أو كلمة المرور غير صحيحة";

const enc = new TextEncoder();
const toHex = (u8) => [...u8].map((b) => b.toString(16).padStart(2, "0")).join("");
const fromHex = (h) => new Uint8Array(h.match(/../g).map((x) => parseInt(x, 16)));
const randHex = (n) => toHex(crypto.getRandomValues(new Uint8Array(n)));
const uid = () => crypto.randomUUID().replace(/-/g, "");
const nowIso = () => new Date().toISOString();
const sha256Hex = async (s) => toHex(new Uint8Array(await crypto.subtle.digest("SHA-256", enc.encode(s))));

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
}
const err = (message, status = 400) => json({ error: message }, status);

async function hashPassword(password, saltHex) {
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", hash: "SHA-256", salt: fromHex(saltHex), iterations: PBKDF2_ITERATIONS },
    key,
    256
  );
  return toHex(new Uint8Array(bits));
}
function safeEqual(a, b) {
  if (a.length !== b.length) return false;
  let r = 0;
  for (let i = 0; i < a.length; i++) r |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return r === 0;
}

let schemaReady = null;
function ensureSchema(env) {
  if (!schemaReady) {
    const db = env.DB;
    schemaReady = db
      .batch([
        db.prepare(
          "CREATE TABLE IF NOT EXISTS users (id TEXT PRIMARY KEY, username TEXT NOT NULL, username_lc TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, pass_hash TEXT NOT NULL, data TEXT NOT NULL DEFAULT '{}', fails INTEGER NOT NULL DEFAULT 0, locked_until INTEGER NOT NULL DEFAULT 0, created_date TEXT NOT NULL)"
        ),
        db.prepare(
          "CREATE TABLE IF NOT EXISTS sessions (token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL, created_date TEXT NOT NULL)"
        ),
        db.prepare(
          "CREATE TABLE IF NOT EXISTS records (id TEXT PRIMARY KEY, entity TEXT NOT NULL, owner TEXT NOT NULL, data TEXT NOT NULL, created_date TEXT NOT NULL, updated_date TEXT NOT NULL)"
        ),
        db.prepare("CREATE INDEX IF NOT EXISTS idx_records_owner ON records(owner, entity)"),
        db.prepare(
          "CREATE TABLE IF NOT EXISTS files (id TEXT PRIMARY KEY, owner TEXT NOT NULL, name TEXT, type TEXT, size INTEGER, chunks INTEGER NOT NULL DEFAULT 0, created_date TEXT NOT NULL)"
        ),
        db.prepare(
          "CREATE TABLE IF NOT EXISTS file_chunks (file_id TEXT NOT NULL, idx INTEGER NOT NULL, data TEXT NOT NULL, PRIMARY KEY (file_id, idx))"
        ),
      ])
      .catch((e) => {
        schemaReady = null;
        throw e;
      });
  }
  return schemaReady;
}

// ---------- المستخدمون ----------
function userOut(row) {
  let data = {};
  try {
    data = JSON.parse(row.data || "{}");
  } catch (_) {
    /* ignore */
  }
  return {
    id: row.id,
    username: row.username,
    email: row.username,
    full_name: data.display_name || row.username,
    role: "user",
    created_date: row.created_date,
    data,
  };
}

async function createSession(env, userId) {
  const token = randHex(32);
  await env.DB.prepare("INSERT INTO sessions (token_hash, user_id, created_date) VALUES (?, ?, ?)")
    .bind(await sha256Hex(token), userId, nowIso())
    .run();
  return token;
}

async function getUser(request, env) {
  const h = request.headers.get("Authorization") || "";
  const token = h.startsWith("Bearer ") ? h.slice(7).trim() : "";
  if (!token) return null;
  const row = await env.DB.prepare(
    "SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?"
  )
    .bind(await sha256Hex(token))
    .first();
  return row || null;
}

async function handleAuth(request, env, action, body) {
  if (action === "register" && request.method === "POST") {
    const username = String(body.username || "").trim();
    const password = String(body.password || "");
    const display = String(body.display_name || "").trim().slice(0, 40);
    if (!/^[\p{L}\p{N}_.-]{3,24}$/u.test(username))
      return err("اسم المستخدم من 3 إلى 24 خانة: حروف وأرقام و _ . - فقط");
    if (password.length < 6 || password.length > 100) return err("كلمة المرور لازم تكون 6 خانات على الأقل");
    const lc = username.toLowerCase();
    const exists = await env.DB.prepare("SELECT 1 AS x FROM users WHERE username_lc = ?").bind(lc).first();
    if (exists) return err("اسم المستخدم مأخوذ، جرّب اسم ثاني", 409);
    const salt = randHex(16);
    const hash = await hashPassword(password, salt);
    const id = uid();
    const created = nowIso();
    const data = JSON.stringify(display ? { display_name: display } : {});
    try {
      await env.DB.prepare(
        "INSERT INTO users (id, username, username_lc, salt, pass_hash, data, created_date) VALUES (?, ?, ?, ?, ?, ?, ?)"
      )
        .bind(id, username, lc, salt, hash, data, created)
        .run();
    } catch (e) {
      return err("اسم المستخدم مأخوذ، جرّب اسم ثاني", 409);
    }
    const token = await createSession(env, id);
    return json({ token, user: userOut({ id, username, data, created_date: created }) });
  }

  if (action === "login" && request.method === "POST") {
    const username = String(body.username || "").trim().toLowerCase();
    const password = String(body.password || "");
    if (!username || !password) return err(INVALID_LOGIN, 401);
    const row = await env.DB.prepare("SELECT * FROM users WHERE username_lc = ?").bind(username).first();
    if (!row) return err(INVALID_LOGIN, 401);
    if (row.locked_until > Date.now()) return err("محاولات كثيرة، جرّب بعد كم دقيقة", 429);
    const ok = safeEqual(await hashPassword(password, row.salt), row.pass_hash);
    if (!ok) {
      const fails = row.fails + 1;
      if (fails >= 8) {
        await env.DB.prepare("UPDATE users SET fails = 0, locked_until = ? WHERE id = ?")
          .bind(Date.now() + 5 * 60 * 1000, row.id)
          .run();
      } else {
        await env.DB.prepare("UPDATE users SET fails = ? WHERE id = ?").bind(fails, row.id).run();
      }
      return err(INVALID_LOGIN, 401);
    }
    if (row.fails) await env.DB.prepare("UPDATE users SET fails = 0 WHERE id = ?").bind(row.id).run();
    const token = await createSession(env, row.id);
    return json({ token, user: userOut(row) });
  }

  const user = await getUser(request, env);
  if (!user) return err("سجّل دخولك أول", 401);

  if (action === "me" && request.method === "GET") return json(userOut(user));

  if (action === "update" && request.method === "POST") {
    const patch = body.patch && typeof body.patch === "object" ? body.patch : {};
    let data = {};
    try {
      data = JSON.parse(user.data || "{}");
    } catch (_) {
      /* ignore */
    }
    for (const [k, v] of Object.entries(patch)) {
      if (k === "__proto__" || k === "constructor" || k === "prototype") continue;
      data[k] = v;
    }
    const str = JSON.stringify(data);
    if (str.length > 20000) return err("البيانات كبيرة");
    await env.DB.prepare("UPDATE users SET data = ? WHERE id = ?").bind(str, user.id).run();
    return json(userOut({ ...user, data: str }));
  }

  if (action === "password" && request.method === "POST") {
    const current = String(body.current || "");
    const next = String(body.next || "");
    if (next.length < 6 || next.length > 100) return err("كلمة المرور الجديدة لازم تكون 6 خانات على الأقل");
    if (!safeEqual(await hashPassword(current, user.salt), user.pass_hash)) return err("كلمة المرور الحالية غلط", 401);
    const salt = randHex(16);
    const hash = await hashPassword(next, salt);
    await env.DB.prepare("UPDATE users SET salt = ?, pass_hash = ? WHERE id = ?").bind(salt, hash, user.id).run();
    return json({ success: true });
  }

  if (action === "logout" && request.method === "POST") {
    const h = request.headers.get("Authorization") || "";
    const token = h.slice(7).trim();
    await env.DB.prepare("DELETE FROM sessions WHERE token_hash = ?").bind(await sha256Hex(token)).run();
    return json({ success: true });
  }

  return err("غير موجود", 404);
}

// ---------- البيانات (Entities) ----------
const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
const present = (v) => v !== undefined && v !== null && v !== "";
function eq(val, target) {
  if (Array.isArray(val) && !Array.isArray(target)) return val.includes(target);
  return val === target;
}
function matchField(val, cond) {
  if (!isObj(cond)) return eq(val, cond);
  for (const [op, arg] of Object.entries(cond)) {
    switch (op) {
      case "$exists":
        if (present(val) !== !!arg) return false;
        break;
      case "$ne":
        if (eq(val, arg)) return false;
        break;
      case "$eq":
        if (!eq(val, arg)) return false;
        break;
      case "$in":
        if (!Array.isArray(arg) || !arg.some((a) => eq(val, a))) return false;
        break;
      case "$nin":
        if (Array.isArray(arg) && arg.some((a) => eq(val, a))) return false;
        break;
      case "$gt":
        if (!(val != null && val > arg)) return false;
        break;
      case "$gte":
        if (!(val != null && val >= arg)) return false;
        break;
      case "$lt":
        if (!(val != null && val < arg)) return false;
        break;
      case "$lte":
        if (!(val != null && val <= arg)) return false;
        break;
      case "$regex": {
        let re;
        try {
          re = new RegExp(String(arg), String(cond.$options || "").replace(/[^imsu]/g, ""));
        } catch (_) {
          return false;
        }
        if (!re.test(val == null ? "" : String(val))) return false;
        break;
      }
      case "$options":
        break;
      default:
        return false;
    }
  }
  return true;
}
function matches(doc, q) {
  if (!isObj(q)) return true;
  for (const [k, cond] of Object.entries(q)) {
    if (k === "$or") {
      if (!Array.isArray(cond) || !cond.some((s) => matches(doc, s))) return false;
    } else if (k === "$and") {
      if (!Array.isArray(cond) || !cond.every((s) => matches(doc, s))) return false;
    } else if (!matchField(doc[k], cond)) return false;
  }
  return true;
}

const RESERVED = ["id", "created_date", "updated_date", "created_by"];
function cleanData(d) {
  const out = {};
  if (!isObj(d)) return out;
  for (const [k, v] of Object.entries(d)) {
    if (RESERVED.includes(k) || k === "__proto__" || k === "constructor" || v === undefined) continue;
    out[k] = v;
  }
  return out;
}
function applyUpdate(data, upd) {
  const src = isObj(upd) && isObj(upd.$set) ? upd.$set : upd;
  return { ...data, ...cleanData(src) };
}
const toDoc = (row, user) => ({
  ...JSON.parse(row.data),
  id: row.id,
  created_date: row.created_date,
  updated_date: row.updated_date,
  created_by: user.username,
});

async function loadAll(env, user, entity) {
  const { results } = await env.DB.prepare(
    "SELECT id, data, created_date, updated_date FROM records WHERE owner = ? AND entity = ?"
  )
    .bind(user.id, entity)
    .all();
  return (results || []).map((r) => toDoc(r, user));
}

async function runBatch(env, stmts) {
  for (let i = 0; i < stmts.length; i += 50) await env.DB.batch(stmts.slice(i, i + 50));
}

async function dropFiles(env, user, docs) {
  const ids = [...new Set(docs.map((d) => d.file_uri).filter(Boolean))];
  const stmts = [];
  for (const id of ids) {
    stmts.push(env.DB.prepare("DELETE FROM file_chunks WHERE file_id = (SELECT id FROM files WHERE id = ? AND owner = ?)").bind(id, user.id));
    stmts.push(env.DB.prepare("DELETE FROM files WHERE id = ? AND owner = ?").bind(id, user.id));
  }
  if (stmts.length) await runBatch(env, stmts);
}

async function handleEntity(env, user, entity, body) {
  const op = body.op;
  const now = nowIso();

  if (op === "create") {
    const data = cleanData(body.data);
    const str = JSON.stringify(data);
    if (str.length > MAX_RECORD_BYTES) return err("حجم العنصر كبير جداً");
    const id = uid();
    await env.DB.prepare(
      "INSERT INTO records (id, entity, owner, data, created_date, updated_date) VALUES (?, ?, ?, ?, ?, ?)"
    )
      .bind(id, entity, user.id, str, now, now)
      .run();
    return json({ ...data, id, created_date: now, updated_date: now, created_by: user.username });
  }

  if (op === "get" || op === "update" || op === "delete") {
    const id = String(body.id || "");
    const row = await env.DB.prepare(
      "SELECT id, data, created_date, updated_date FROM records WHERE id = ? AND entity = ? AND owner = ?"
    )
      .bind(id, entity, user.id)
      .first();
    if (!row) return err("غير موجود", 404);
    if (op === "get") return json(toDoc(row, user));
    if (op === "delete") {
      await env.DB.prepare("DELETE FROM records WHERE id = ? AND owner = ?").bind(id, user.id).run();
      if (entity === "Item") await dropFiles(env, user, [JSON.parse(row.data)]);
      return json({ success: true });
    }
    const merged = applyUpdate(JSON.parse(row.data), body.data);
    const str = JSON.stringify(merged);
    if (str.length > MAX_RECORD_BYTES) return err("حجم العنصر كبير جداً");
    await env.DB.prepare("UPDATE records SET data = ?, updated_date = ? WHERE id = ? AND owner = ?")
      .bind(str, now, id, user.id)
      .run();
    return json({ ...merged, id, created_date: row.created_date, updated_date: now, created_by: user.username });
  }

  if (op === "filter" || op === "count" || op === "aggregate" || op === "updateMany" || op === "deleteMany") {
    const query = isObj(body.query) ? body.query : {};
    const all = (await loadAll(env, user, entity)).filter((d) => matches(d, query));

    if (op === "count") return json({ count: all.length });

    if (op === "aggregate") {
      const g = String(body.groupBy || "");
      const m = new Map();
      for (const d of all) {
        const k = d[g] === undefined ? null : d[g];
        m.set(k, (m.get(k) || 0) + 1);
      }
      return json({ rows: [...m.entries()].map(([k, count]) => ({ [g]: k, count })) });
    }

    if (op === "updateMany") {
      const stmts = all.map((d) => {
        const { id, created_date, updated_date, created_by, ...rest } = d;
        const merged = applyUpdate(rest, body.update);
        return env.DB.prepare("UPDATE records SET data = ?, updated_date = ? WHERE id = ? AND owner = ?").bind(
          JSON.stringify(merged), now, id, user.id
        );
      });
      await runBatch(env, stmts);
      return json({ success: true, updated: all.length });
    }

    if (op === "deleteMany") {
      const stmts = all.map((d) => env.DB.prepare("DELETE FROM records WHERE id = ? AND owner = ?").bind(d.id, user.id));
      await runBatch(env, stmts);
      if (entity === "Item") await dropFiles(env, user, all);
      return json({ success: true, deleted: all.length });
    }

    // filter
    const sortStr = typeof body.sort === "string" && body.sort ? body.sort : "-created_date";
    const desc = sortStr.startsWith("-");
    const field = sortStr.replace(/^[-+]/, "");
    all.sort((a, b) => {
      const x = a[field];
      const y = b[field];
      if (x === y) return 0;
      if (x === undefined || x === null) return 1;
      if (y === undefined || y === null) return -1;
      return (x < y ? -1 : 1) * (desc ? -1 : 1);
    });
    const limit = Math.min(Math.max(parseInt(body.limit, 10) || 50, 1), 500);
    const offset = Math.max(parseInt(body.cursor, 10) || 0, 0);
    let items = all.slice(offset, offset + limit);
    if (Array.isArray(body.fields) && body.fields.length) {
      const keep = new Set([...body.fields, "id", "created_date", "updated_date"]);
      items = items.map((d) => Object.fromEntries(Object.entries(d).filter(([k]) => keep.has(k))));
    }
    const hasMore = offset + limit < all.length;
    return json({ items, has_more: hasMore, next_cursor: hasMore ? String(offset + limit) : null });
  }

  return err("عملية غير معروفة");
}

// ---------- الملفات ----------
async function ownFile(env, user, id) {
  return env.DB.prepare("SELECT * FROM files WHERE id = ? AND owner = ?").bind(id, user.id).first();
}

async function handleFiles(request, env, user, parts, body) {
  const [first, second, third] = parts;
  if (first === "init" && request.method === "POST") {
    const id = "f_" + uid();
    await env.DB.prepare(
      "INSERT INTO files (id, owner, name, type, size, chunks, created_date) VALUES (?, ?, ?, ?, ?, 0, ?)"
    )
      .bind(id, user.id, String(body.name || "").slice(0, 200), String(body.type || "").slice(0, 100), Number(body.size) || 0, nowIso())
      .run();
    return json({ file_id: id });
  }
  const id = first;
  const f = await ownFile(env, user, id);
  if (!f) return err("الملف غير موجود", 404);
  if (second === "chunk" && request.method === "POST") {
    const idx = parseInt(body.idx, 10);
    const data = typeof body.data === "string" ? body.data : "";
    if (!(idx >= 0 && idx < MAX_CHUNKS) || !data || data.length > MAX_CHUNK_CHARS) return err("جزء ملف غير صالح");
    await env.DB.prepare("INSERT OR REPLACE INTO file_chunks (file_id, idx, data) VALUES (?, ?, ?)").bind(id, idx, data).run();
    return json({ success: true });
  }
  if (second === "done" && request.method === "POST") {
    const n = parseInt(body.chunks, 10);
    if (!(n > 0 && n <= MAX_CHUNKS)) return err("عدد الأجزاء غير صالح");
    await env.DB.prepare("UPDATE files SET chunks = ? WHERE id = ?").bind(n, id).run();
    return json({ success: true });
  }
  if (second === undefined && request.method === "GET") {
    return json({ id, name: f.name, type: f.type, size: f.size, chunks: f.chunks });
  }
  if (second === "chunk" && third !== undefined && request.method === "GET") {
    const row = await env.DB.prepare("SELECT data FROM file_chunks WHERE file_id = ? AND idx = ?")
      .bind(id, parseInt(third, 10))
      .first();
    if (!row) return err("غير موجود", 404);
    return json({ data: row.data });
  }
  return err("غير موجود", 404);
}

// ---------- المشاركة (عامة بدون تسجيل دخول) ----------
async function shareLookup(env, token) {
  const row = await env.DB.prepare(
    "SELECT * FROM records WHERE entity = 'ShareLink' AND json_extract(data, '$.token') = ? LIMIT 1"
  )
    .bind(token)
    .first();
  if (!row) return null;
  const d = JSON.parse(row.data);
  if (d.is_active === false) return { expired: true };
  if (d.expires_at && new Date(d.expires_at).getTime() < Date.now()) return { expired: true };
  const item = await env.DB.prepare("SELECT * FROM records WHERE id = ? AND entity = 'Item' AND owner = ?")
    .bind(String(d.item_id || ""), row.owner)
    .first();
  if (!item) return { expired: true };
  const idata = JSON.parse(item.data);
  if (idata.deleted_at) return { expired: true };
  return { item: { ...idata, id: item.id }, owner: row.owner };
}

async function handleShare(request, env, parts) {
  const [token, what, idx] = parts;
  if (!token || request.method !== "GET") return err("غير موجود", 404);
  const r = await shareLookup(env, token);
  if (!r) return json({ status: "not_found" });
  if (r.expired) return json({ status: "expired" });
  const fileId = r.item.file_uri || "";
  if (what === "file") {
    if (!fileId) return err("غير موجود", 404);
    const row = await env.DB.prepare(
      "SELECT c.data AS data FROM file_chunks c JOIN files f ON f.id = c.file_id WHERE c.file_id = ? AND f.owner = ? AND c.idx = ?"
    )
      .bind(fileId, r.owner, parseInt(idx, 10))
      .first();
    if (!row) return err("غير موجود", 404);
    return json({ data: row.data });
  }
  let chunks = 0;
  if (fileId) {
    const f = await env.DB.prepare("SELECT chunks FROM files WHERE id = ? AND owner = ?").bind(fileId, r.owner).first();
    chunks = f ? f.chunks : 0;
  }
  return json({ status: "ok", item: r.item, file_chunks: chunks });
}

// ---------- الراوتر ----------
async function route(request, env, url) {
  const parts = url.pathname.replace(/^\/api\/?/, "").split("/").filter(Boolean).map(decodeURIComponent);
  const [a, b, ...rest] = parts;
  const body = request.method === "GET" ? {} : await request.json().catch(() => ({}));

  if (a === "auth") return handleAuth(request, env, b, body);
  if (a === "share") return handleShare(request, env, [b, ...rest]);

  const user = await getUser(request, env);
  if (!user) return err("سجّل دخولك أول", 401);

  if (a === "e" && request.method === "POST") {
    if (!ENTITIES.has(b)) return err("نوع بيانات غير معروف", 404);
    return handleEntity(env, user, b, body);
  }
  if (a === "files") return handleFiles(request, env, user, [b, ...rest], body);
  return err("غير موجود", 404);
}

async function serveAsset(request, env, url) {
  if (!env.ASSETS) return new Response("Not found", { status: 404 });
  const res = await env.ASSETS.fetch(request);
  if (res.status === 404 && request.method === "GET" && !/\.[a-z0-9]+$/i.test(url.pathname)) {
    return env.ASSETS.fetch(new Request(new URL("/index.html", url), request));
  }
  return res;
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith("/api/")) return serveAsset(request, env, url);
    if (!env.DB) return err("قاعدة البيانات (DB) غير مربوطة في كلاودفلير", 500);
    try {
      await ensureSchema(env);
      return await route(request, env, url);
    } catch (e) {
      console.error(e);
      return err("صار خطأ في السيرفر، جرّب مرة ثانية", 500);
    }
  },
};
