import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Loader2, Plus, X } from "lucide-react";
import { api } from "@/api/client";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";

const PRIORITIES = [
  { value: "low", label: "منخفضة" },
  { value: "medium", label: "متوسطة" },
  { value: "high", label: "عالية" },
  { value: "urgent", label: "عاجلة" },
];
const STATUSES = [
  { value: "not_started", label: "لم تبدأ" },
  { value: "in_progress", label: "قيد التنفيذ" },
  { value: "completed", label: "مكتملة" },
  { value: "deferred", label: "مؤجلة" },
];

export default function TaskEditor({ open, onOpenChange, task, presetProjectId }) {
  const isEdit = !!task;
  const [form, setForm] = useState({});
  const [projects, setProjects] = useState([]);
  const [saving, setSaving] = useState(false);
  const [newCheck, setNewCheck] = useState("");

  useEffect(() => {
    if (!open) return;
    if (task) {
      setForm({ ...task, tagsStr: (task.tags || []).join("، "), checklist: task.checklist || [] });
    } else {
      setForm({
        title: "", description: "", due_date: "", priority: "medium",
        status: "not_started", tagsStr: "", project_id: presetProjectId || "", checklist: [],
      });
    }
  }, [open, task, presetProjectId]);

  useEffect(() => {
    if (!open) return;
    api.entities.Project.filter({}, { sort: "-created_date", limit: 100, fields: ["name"] })
      .then((r) => setProjects(r.items || []))
      .catch(() => {});
  }, [open]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const addCheck = () => {
    if (!newCheck.trim()) return;
    set("checklist", [...(form.checklist || []), { text: newCheck.trim(), done: false }]);
    setNewCheck("");
  };
  const toggleCheck = (i) => {
    const list = [...(form.checklist || [])];
    list[i] = { ...list[i], done: !list[i].done };
    set("checklist", list);
  };
  const removeCheck = (i) => set("checklist", (form.checklist || []).filter((_, idx) => idx !== i));

  const save = async () => {
    if (!form.title?.trim()) {
      toast({ title: "العنوان مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const tagsArr = (form.tagsStr || "").split(/[،,]/).map((s) => s.trim()).filter(Boolean);
      const payload = {
        title: form.title.trim(),
        description: form.description || "",
        due_date: form.due_date || "",
        priority: form.priority || "medium",
        status: form.status || "not_started",
        tags: tagsArr,
        project_id: form.project_id || "",
        checklist: form.checklist || [],
      };
      if (isEdit) {
        await api.entities.Task.update(task.id, payload);
        await logActivity("update", `تعديل المهمة: ${payload.title}`, { entity_type: "Task", entity_id: task.id });
      } else {
        const created = await api.entities.Task.create(payload);
        await logActivity("create", `مهمة جديدة: ${payload.title}`, { entity_type: "Task", entity_id: created.id });
      }
      toast({ title: isEdit ? "تم الحفظ" : "تم إنشاء المهمة" });
      emitDataChanged();
      onOpenChange(false);
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-h-[92vh] overflow-y-auto rounded-[2rem] p-0 sm:max-w-lg">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle>{isEdit ? "تعديل المهمة" : "مهمة جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 px-6 py-4">
          <div className="space-y-2">
            <Label>العنوان</Label>
            <Input value={form.title ?? ""} onChange={(e) => set("title", e.target.value)} className="h-11 rounded-xl" placeholder="ما المهمة؟" />
          </div>
          <div className="space-y-2">
            <Label>الوصف</Label>
            <Textarea value={form.description ?? ""} onChange={(e) => set("description", e.target.value)} className="min-h-[70px] rounded-xl" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>الأولوية</Label>
              <Select value={form.priority ?? "medium"} onValueChange={(v) => set("priority", v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {PRIORITIES.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الحالة</Label>
              <Select value={form.status ?? "not_started"} onValueChange={(v) => set("status", v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {STATUSES.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>تاريخ الاستحقاق</Label>
              <Input type="date" value={form.due_date ?? ""} onChange={(e) => set("due_date", e.target.value)} className="h-11 rounded-xl" />
            </div>
            <div className="space-y-2">
              <Label>المشروع</Label>
              <Select value={form.project_id ?? "none"} onValueChange={(v) => set("project_id", v === "none" ? "" : v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue placeholder="بدون" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون مشروع</SelectItem>
                  {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>الوسوم</Label>
            <Input value={form.tagsStr ?? ""} onChange={(e) => set("tagsStr", e.target.value)} className="h-11 rounded-xl" placeholder="افصل بفاصلة" />
          </div>
          <div className="space-y-2">
            <Label>قائمة تحقق</Label>
            <div className="space-y-2">
              {(form.checklist || []).map((c, i) => (
                <div key={i} className="glass-soft flex items-center gap-2 rounded-xl px-3 py-2">
                  <button onClick={() => toggleCheck(i)} className={`h-5 w-5 shrink-0 rounded-md border ${c.done ? "border-transparent" : "border-border"}`} style={c.done ? { background: "hsl(var(--accent))" } : {}} type="button" />
                  <span className={`flex-1 text-sm ${c.done ? "line-through opacity-50" : ""}`}>{c.text}</span>
                  <button onClick={() => removeCheck(i)} type="button"><X className="h-4 w-4 text-muted-foreground" /></button>
                </div>
              ))}
              <div className="flex gap-2">
                <Input value={newCheck} onChange={(e) => setNewCheck(e.target.value)} onKeyDown={(e) => e.key === "Enter" && addCheck()} placeholder="عنصر جديد…" className="h-10 rounded-xl" />
                <Button type="button" size="sm" onClick={addCheck} className="rounded-xl"><Plus className="h-4 w-4" /></Button>
              </div>
            </div>
          </div>
        </div>
        <div className="sticky bottom-0 glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">إلغاء</Button>
            <Button onClick={save} disabled={saving} className="rounded-xl">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ" : "إنشاء"}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}