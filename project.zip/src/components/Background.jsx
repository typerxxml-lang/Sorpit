/**
 * Solid single-color backdrop (no gradients, grids, or rings).
 * Purely decorative; pointer-events disabled.
 */
export default function Background() {
  return <div className="fixed inset-0 -z-10 bg-background" aria-hidden="true" />;
}