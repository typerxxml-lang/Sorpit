import { useState } from "react";
import { Star, MoreVertical, Archive, Trash2, Pencil, ExternalLink } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { useFileUrl } from "@/lib/useFileUrl";
import { TYPE_META, formatBytes, timeAgo, stripHtml } from "@/lib/itemHelpers";
import { useItemEditor } from "@/components/ItemEditorProvider";
import { api } from "@/api/client";
import { emitDataChanged } from "@/lib/dataEvents";
import { toast } from "@/components/ui/use-toast";

export default function ItemCard({ item, view = "grid" }) {
  const { openItem } = useItemEditor();
  const meta = TYPE_META[item.type] || TYPE_META.note;
  const Icon = meta.icon;
  const { url: imgUrl } = useFileUrl(item.type === "image" ? item.file_uri : null);
  const [busy, setBusy] = useState(false);

  const act = async (fn, msg) => {
    setBusy(true);
    try {
      await fn();
      emitDataChanged();
      if (msg) toast({ title: msg });
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const toggleFav = (e) => {
    e.stopPropagation();
    act(() => api.entities.Item.update(item.id, { is_favorite: !item.is_favorite }));
  };
  const archive = () => act(() => api.entities.Item.update(item.id, { is_archived: true }), "تمت الأرشفة");
  const softDelete = () =>
    act(() => api.entities.Item.update(item.id, { deleted_at: new Date().toISOString() }), "نُقل إلى السلة");
  const restore = () =>
    act(() => api.entities.Item.update(item.id, { deleted_at: "" }), "تمت الاستعادة");
  const unarchive = () => act(() => api.entities.Item.update(item.id, { is_archived: false }), "أُلغي الأرشفة");
  const permanentDelete = () =>
    act(() => api.entities.Item.delete(item.id), "حُذف نهائيًا");

  const accent = item.color || meta.color;
  const isList = view === "list";

  return (
    <div
      onClick={() => openItem(item)}
      className={`glass-soft group relative cursor-pointer overflow-hidden rounded-3xl transition active:scale-[0.98] ${
        isList ? "flex items-center gap-3 p-3" : "flex flex-col p-3"
      }`}
    >
      {/* thumb / icon */}
      {item.type === "image" && imgUrl ? (
        <div className={`relative overflow-hidden rounded-2xl ${isList ? "h-16 w-16 shrink-0" : "aspect-video w-full"}`}>
          <img src={imgUrl} alt={item.title} className="h-full w-full object-cover" />
        </div>
      ) : (
        <div
          className={`glass-soft flex items-center justify-center rounded-2xl ${isList ? "h-16 w-16 shrink-0" : "mb-3 aspect-video w-full"}`}
          style={{ color: `hsl(${accent})` }}
        >
          <Icon className={isList ? "h-6 w-6" : "h-10 w-10"} />
        </div>
      )}

      <div className={isList ? "min-w-0 flex-1" : "min-w-0 flex-1"}>
        <div className="flex items-start justify-between gap-2">
          <h3 className="truncate text-sm font-bold leading-tight">{item.title}</h3>
          <button
            onClick={toggleFav}
            className="shrink-0 transition active:scale-90"
            aria-label="مفضلة"
          >
            <Star
              className={`h-4 w-4 ${item.is_favorite ? "fill-current" : ""}`}
              style={item.is_favorite ? { color: `hsl(${accent})` } : {}}
            />
          </button>
        </div>

        {item.type === "note" && item.content && (
          <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{stripHtml(item.content)}</p>
        )}
        {item.type === "link" && item.url && (
          <p dir="ltr" className="mt-1 truncate text-left text-xs text-muted-foreground">{item.url}</p>
        )}
        {item.type === "file" && (
          <p className="mt-1 text-xs text-muted-foreground">{formatBytes(item.file_size)}</p>
        )}

        <div className="mt-2 flex items-center justify-between">
          <span className="text-[10px] text-muted-foreground/70">{timeAgo(item.updated_date || item.created_date)}</span>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                onClick={(e) => e.stopPropagation()}
                className="glass-soft flex h-7 w-7 items-center justify-center rounded-lg opacity-70 transition active:scale-90"
                aria-label="إجراءات"
              >
                <MoreVertical className="h-4 w-4" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="glass rounded-2xl">
              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); openItem(item); }}>
                <Pencil className="h-4 w-4" /> تعديل
              </DropdownMenuItem>
              {item.type === "link" && item.url && (
                <DropdownMenuItem asChild>
                  <a href={item.url} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>
                    <ExternalLink className="h-4 w-4" /> فتح الرابط
                  </a>
                </DropdownMenuItem>
              )}
              {item.is_archived ? (
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); unarchive(); }}>
                  <Archive className="h-4 w-4" /> إلغاء الأرشفة
                </DropdownMenuItem>
              ) : (
                <DropdownMenuItem onClick={(e) => { e.stopPropagation(); archive(); }}>
                  <Archive className="h-4 w-4" /> أرشفة
                </DropdownMenuItem>
              )}
              {item.deleted_at ? (
                <>
                  <DropdownMenuItem onClick={(e) => { e.stopPropagation(); restore(); }}>
                    <Archive className="h-4 w-4" /> استعادة
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    className="text-destructive"
                    onClick={(e) => { e.stopPropagation(); permanentDelete(); }}
                  >
                    <Trash2 className="h-4 w-4" /> حذف نهائي
                  </DropdownMenuItem>
                </>
              ) : (
                <DropdownMenuItem
                  className="text-destructive"
                  onClick={(e) => { e.stopPropagation(); softDelete(); }}
                >
                  <Trash2 className="h-4 w-4" /> نقل للسلة
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}