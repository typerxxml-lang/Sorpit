import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2 } from "lucide-react";
import { api } from "@/api/client";
import { ACCENTS } from "@/lib/theme";
import { PROJECT_STATUS } from "@/lib/itemHelpers";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";

const COLOR_CHOICES = Object.entries(ACCENTS);

export default function ProjectEditor({ open, onOpenChange, project }) {
  const isEdit = !!project;
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    if (project) {
      setForm({ ...project, tagsStr: (project.tags || []).join("، ") });
    } else {
      setForm({
        name: "",
        description: "",
        cover_color: "250 82% 72%",
        category: "",
        status: "new",
        tagsStr: "",
        due_date: "",
      });
    }
  }, [open, project]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = async () => {
    if (!(form.name || project?.name)?.trim()) {
      toast({ title: "اسم المشروع مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const tagsArr = (form.tagsStr || "")
        .split(/[،,]/)
        .map((s) => s.trim())
        .filter(Boolean);
      const payload = {
        name: (form.name || project?.name).trim(),
        description: form.description ?? project?.description ?? "",
        cover_color: form.cover_color || project?.cover_color || "250 82% 72%",
        category: form.category ?? project?.category ?? "",
        status: form.status || project?.status || "new",
        tags: tagsArr,
        due_date: form.due_date ?? project?.due_date ?? "",
      };
      if (isEdit) {
        await api.entities.Project.update(project.id, payload);
      } else {
        await api.entities.Project.create(payload);
      }
      toast({ title: isEdit ? "تم الحفظ" : "أُنشئ المشروع" });
      emitDataChanged();
      onOpenChange(false);
    } catch (err) {
      toast({ title: "خطأ", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-h-[92vh] overflow-y-auto rounded-[2rem] p-0 sm:max-w-lg">
        <div className="sticky top-0 z-10 glass rounded-t-[2rem] px-6 py-4">
          <DialogHeader className="text-right">
            <DialogTitle>{isEdit ? "تعديل المشروع" : "مشروع جديد"}</DialogTitle>
          </DialogHeader>
        </div>

        <div className="space-y-5 px-6 py-5">
          <div className="space-y-2">
            <Label>اسم المشروع</Label>
            <Input
              value={form.name ?? project?.name ?? ""}
              onChange={(e) => set("name", e.target.value)}
              className="h-11 rounded-xl"
              placeholder="اسم المشروع"
            />
          </div>
          <div className="space-y-2">
            <Label>الوصف</Label>
            <Textarea
              value={form.description ?? project?.description ?? ""}
              onChange={(e) => set("description", e.target.value)}
              className="min-h-[70px] rounded-xl"
              placeholder="وصف اختياري"
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>الحالة</Label>
              <Select value={form.status ?? project?.status ?? "new"} onValueChange={(v) => set("status", v)}>
                <SelectTrigger className="h-11 rounded-xl">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(PROJECT_STATUS).map(([k, v]) => (
                    <SelectItem key={k} value={k}>
                      {v.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>تاريخ الاستحقاق</Label>
              <Input
                type="date"
                value={(form.due_date ?? project?.due_date ?? "").slice(0, 10)}
                onChange={(e) => set("due_date", e.target.value)}
                className="h-11 rounded-xl"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>التصنيف</Label>
            <Input
              value={form.category ?? project?.category ?? ""}
              onChange={(e) => set("category", e.target.value)}
              className="h-11 rounded-xl"
              placeholder="تصنيف اختياري"
            />
          </div>
          <div className="space-y-2">
            <Label>الوسوم</Label>
            <Input
              value={form.tagsStr ?? ""}
              onChange={(e) => set("tagsStr", e.target.value)}
              className="h-11 rounded-xl"
              placeholder="افصل بفاصلة"
            />
          </div>
          <div className="space-y-2">
            <Label>لون المشروع</Label>
            <div className="flex flex-wrap gap-2">
              {COLOR_CHOICES.map(([k, v]) => (
                <button
                  key={k}
                  type="button"
                  onClick={() => set("cover_color", v)}
                  className={`h-8 w-8 rounded-full border-2 ${(form.cover_color || project?.cover_color) === v ? "border-foreground" : "border-transparent"}`}
                  style={{ background: `hsl(${v})` }}
                  aria-label={k}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="sticky bottom-0 glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">
              إلغاء
            </Button>
            <Button onClick={save} disabled={saving} className="rounded-xl">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ" : "إنشاء"}
            </Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}