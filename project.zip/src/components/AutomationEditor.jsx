import { useEffect, useState } from "react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Loader2 } from "lucide-react";
import { api } from "@/api/client";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";

const TRIGGERS = [
  { value: "item_created", label: "عند إنشاء عنصر" },
  { value: "item_updated", label: "عند تعديل عنصر" },
  { value: "manual", label: "يدوي" },
  { value: "scheduled", label: "مجدول" },
];
const ACTIONS = [
  { value: "tag", label: "إضافة وسم" },
  { value: "set_color", label: "تغيير اللون" },
  { value: "move_folder", label: "نقل لمجلد" },
  { value: "notify", label: "إشعار" },
  { value: "archive", label: "أرشفة" },
];

export default function AutomationEditor({ open, onOpenChange, rule }) {
  const isEdit = !!rule;
  const [form, setForm] = useState({});
  const [saving, setSaving] = useState(false);
  const [folders, setFolders] = useState([]);

  useEffect(() => {
    if (!open) return;
    if (rule) setForm({ ...rule, action_value: rule.action_config?.value || "" });
    else setForm({ name: "", trigger: "item_created", condition: "", action_type: "tag", action_value: "", is_active: true });
  }, [open, rule]);

  useEffect(() => {
    if (!open) return;
    api.entities.Folder.filter({}, { sort: "-created_date", limit: 100, fields: ["name"] })
      .then((r) => setFolders(r.items || []))
      .catch(() => {});
  }, [open]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));
  const save = async () => {
    if (!form.name?.trim()) { toast({ title: "الاسم مطلوب", variant: "destructive" }); return; }
    setSaving(true);
    try {
      const payload = {
        name: form.name.trim(),
        trigger: form.trigger || "manual",
        entity_type: "Item",
        condition: form.condition || "",
        action_type: form.action_type || "tag",
        action_config: { value: form.action_value || "" },
        is_active: form.is_active ?? true,
      };
      if (isEdit) await api.entities.AutomationRule.update(rule.id, payload);
      else {
        const c = await api.entities.AutomationRule.create(payload);
        await logActivity("create", `قاعدة أتمتة: ${payload.name}`, { entity_type: "AutomationRule", entity_id: c.id });
      }
      toast({ title: isEdit ? "تم الحفظ" : "تم إنشاء القاعدة" });
      emitDataChanged();
      onOpenChange(false);
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="glass max-h-[92vh] overflow-y-auto rounded-[2rem] p-0 sm:max-w-md">
        <DialogHeader className="px-6 pt-6 text-right">
          <DialogTitle>{isEdit ? "تعديل القاعدة" : "قاعدة أتمتة جديدة"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 px-6 py-4">
          <div className="space-y-2">
            <Label>اسم القاعدة</Label>
            <Input value={form.name ?? ""} onChange={(e) => set("name", e.target.value)} className="h-11 rounded-xl" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>المحفّز</Label>
              <Select value={form.trigger ?? "manual"} onValueChange={(v) => set("trigger", v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>{TRIGGERS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>الإجراء</Label>
              <Select value={form.action_type ?? "tag"} onValueChange={(v) => set("action_type", v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>{ACTIONS.map((t) => <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>
          <div className="space-y-2">
            <Label>قيمة الإجراء</Label>
            {form.action_type === "move_folder" ? (
              <Select value={form.action_value ?? "none"} onValueChange={(v) => set("action_value", v === "none" ? "" : v)}>
                <SelectTrigger className="h-11 rounded-xl"><SelectValue placeholder="اختر مجلد" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">بدون</SelectItem>
                  {folders.map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
                </SelectContent>
              </Select>
            ) : (
              <Input value={form.action_value ?? ""} onChange={(e) => set("action_value", e.target.value)} className="h-11 rounded-xl" placeholder={form.action_type === "tag" ? "اسم الوسم" : form.action_type === "set_color" ? "قناة HSL" : "نص الإشعار"} />
            )}
          </div>
          <div className="space-y-2">
            <Label>الشرط (اختياري)</Label>
            <Textarea value={form.condition ?? ""} onChange={(e) => set("condition", e.target.value)} className="min-h-[60px] rounded-xl" placeholder="مثال: العنوان يحتوي كلمة" />
          </div>
          <div className="glass-soft flex items-center justify-between rounded-2xl px-4 py-3">
            <Label>مفعّلة</Label>
            <Switch checked={!!form.is_active} onCheckedChange={(v) => set("is_active", v)} />
          </div>
        </div>
        <div className="sticky bottom-0 glass rounded-b-[2rem] px-6 py-4">
          <DialogFooter className="gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)} className="rounded-xl">إلغاء</Button>
            <Button onClick={save} disabled={saving} className="rounded-xl">{saving ? <Loader2 className="h-4 w-4 animate-spin" /> : isEdit ? "حفظ" : "إنشاء"}</Button>
          </DialogFooter>
        </div>
      </DialogContent>
    </Dialog>
  );
}