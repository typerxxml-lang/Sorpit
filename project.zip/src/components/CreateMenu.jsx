import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { FolderKanban, StickyNote, Image as ImageIcon, FileText, Link2, Folder } from "lucide-react";
import { useItemEditor } from "@/components/ItemEditorProvider";
import ProjectEditor from "@/components/ProjectEditor";
import FolderEditor from "@/components/FolderEditor";

const OPTIONS = [
  { key: "project", label: "مشروع", icon: FolderKanban, color: "250 82% 72%" },
  { key: "note", label: "نص وملاحظة", icon: StickyNote, color: "199 85% 60%" },
  { key: "image", label: "صورة", icon: ImageIcon, color: "346 80% 68%" },
  { key: "file", label: "ملف", icon: FileText, color: "38 88% 58%" },
  { key: "link", label: "رابط", icon: Link2, color: "176 72% 48%" },
  { key: "folder", label: "مجلد", icon: Folder, color: "156 64% 48%" },
];

export default function CreateMenu({ open, onOpenChange, presetProjectId, presetFolderId }) {
  const { openCreate } = useItemEditor();
  const [projectOpen, setProjectOpen] = useState(false);
  const [folderOpen, setFolderOpen] = useState(false);

  const choose = (key) => {
    onOpenChange(false);
    if (key === "project") return setProjectOpen(true);
    if (key === "folder") return setFolderOpen(true);
    openCreate(key, presetProjectId, presetFolderId);
  };

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="glass rounded-[2rem] p-0 sm:max-w-md">
          <DialogHeader className="px-6 pt-6 text-right">
            <DialogTitle>إنشاء عنصر جديد</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-3 gap-3 px-6 py-5">
            {OPTIONS.map((o) => {
              const Icon = o.icon;
              return (
                <button
                  key={o.key}
                  onClick={() => choose(o.key)}
                  className="glass-soft flex flex-col items-center gap-2 rounded-3xl p-4 transition active:scale-95"
                >
                  <span
                    className="flex h-12 w-12 items-center justify-center rounded-2xl"
                    style={{ background: `hsl(${o.color} / 0.18)`, color: `hsl(${o.color})` }}
                  >
                    <Icon className="h-6 w-6" />
                  </span>
                  <span className="text-xs font-bold">{o.label}</span>
                </button>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      <ProjectEditor open={projectOpen} onOpenChange={setProjectOpen} />
      <FolderEditor open={folderOpen} onOpenChange={setFolderOpen} />
    </>
  );
}