import { forwardRef } from "react";
import { applyGlass } from "@/lib/glass";
import { useEffect, useRef } from "react";

/**
 * Liquid-glass surface. Large surfaces (header, dock, hero cards) get real
 * light refraction in Chromium; lists fall back to the CSS blur+saturate glass.
 */
const Glass = forwardRef(function Glass(
  { as: Tag = "div", variant = "default", refract = false, radius = 30, edge = 24, scale = 44, className = "", children, ...props },
  forwardedRef
) {
  const innerRef = useRef(null);
  useEffect(() => {
    if (!refract || !innerRef.current) return;
    return applyGlass(innerRef.current, radius, edge, scale);
  }, [refract, radius, edge, scale]);

  const variantClass = variant === "soft" ? "glass-soft" : variant === "pill" ? "glass-pill" : "glass";

  return (
    <Tag
      ref={(node) => {
        innerRef.current = node;
        if (typeof forwardedRef === "function") forwardedRef(node);
        else if (forwardedRef) forwardedRef.current = node;
      }}
      className={`${variantClass} ${className}`}
      {...props}
    >
      {children}
    </Tag>
  );
});

export default Glass;