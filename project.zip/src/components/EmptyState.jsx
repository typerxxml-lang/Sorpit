export default function EmptyState({ icon: Icon, title, description, action }) {
  return (
    <div className="flex flex-col items-center justify-center px-6 py-20 text-center animate-fade-in">
      {Icon && (
        <div
          className="glass-soft mb-6 flex h-20 w-20 items-center justify-center rounded-3xl"
          style={{ color: "hsl(var(--accent))" }}
        >
          <Icon className="h-9 w-9" />
        </div>
      )}
      <h3 className="text-xl font-bold">{title}</h3>
      {description && <p className="mt-2 max-w-sm text-sm text-muted-foreground">{description}</p>}
      {action && <div className="mt-6">{action}</div>}
    </div>
  );
}