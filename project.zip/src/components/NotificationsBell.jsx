import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "@/api/client";
import { Bell } from "lucide-react";

export default function NotificationsBell() {
  const navigate = useNavigate();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    const load = () =>
      api.entities.Notification
        .count({ is_read: { $ne: true } })
        .then((n) => setUnread(n || 0))
        .catch(() => {});
    load();
    const iv = setInterval(load, 30000);
    return () => clearInterval(iv);
  }, []);

  return (
    <button
      onClick={() => navigate("/app/notifications")}
      className="glass-soft relative flex h-10 w-10 items-center justify-center rounded-2xl text-muted-foreground transition active:scale-90"
      aria-label="الإشعارات"
      type="button"
    >
      <Bell className="h-5 w-5" />
      {unread > 0 && (
        <span
          className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full px-1 text-[10px] font-bold text-white"
          style={{ background: "hsl(var(--accent))" }}
        >
          {unread > 9 ? "9+" : unread}
        </span>
      )}
    </button>
  );
}