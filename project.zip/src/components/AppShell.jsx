import { Outlet, useLocation } from "react-router-dom";
import { motion } from "framer-motion";
import Background from "@/components/Background";
import AppHeader from "@/components/AppHeader";
import Dock from "@/components/Dock";
import ItemEditorProvider from "@/components/ItemEditorProvider";
import TermsGate from "@/components/TermsGate";
import Onboarding from "@/components/Onboarding";

export default function AppShell() {
  const { pathname } = useLocation();
  return (
    <div className="relative min-h-screen">
      <Background />
      <ItemEditorProvider>
        <AppHeader />
        <main className="mx-auto w-full max-w-6xl px-4 pb-36 pt-5 sm:px-6">
          <motion.div
            key={pathname}
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            <Outlet />
          </motion.div>
        </main>
        <Dock />
      </ItemEditorProvider>
      <Onboarding />
      <TermsGate />
    </div>
  );
}
