import { motion } from "framer-motion";

/**
 * Sorpit mark — a geometric "gathering space": four content chips (project,
 * image, doc, note) converging into one rounded container, connected by a
 * central node. Not a plain letter.
 */
export default function Logo({ size = 44, animated = false, className = "" }) {
  const chips = [
    { x: -10, y: -10, r: 4.5, delay: 0 },
    { x: 10, y: -10, r: 4.5, delay: 0.08 },
    { x: -10, y: 10, r: 4.5, delay: 0.16 },
    { x: 10, y: 10, r: 4.5, delay: 0.24 },
  ];

  const Wrapper = animated ? motion.g : "g";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      className={className}
      aria-label="Sorpit"
    >
      <defs>
        <linearGradient id="sorpit-mark" x1="6" y1="6" x2="42" y2="42">
          <stop stopColor="hsl(var(--accent))" />
          <stop offset="1" stopColor="hsl(var(--accent))" stopOpacity="0.7" />
        </linearGradient>
      </defs>
      {/* outer container — the space */}
      <rect
        x="6"
        y="6"
        width="36"
        height="36"
        rx="12"
        stroke="hsl(var(--accent))"
        strokeWidth="2.2"
        opacity="0.9"
      />
      {/* connection lines to center */}
      {chips.map((c, i) => (
        <line
          key={i}
          x1="24"
          y1="24"
          x2={24 + c.x}
          y2={24 + c.y}
          stroke="hsl(var(--accent))"
          strokeWidth="1.4"
          opacity="0.45"
        />
      ))}
      {/* central node */}
      <circle cx="24" cy="24" r="4" fill="hsl(var(--accent))" />
      {/* converging content chips */}
      {chips.map((c, i) =>
        animated ? (
          <motion.circle
            key={i}
            cx={24 + c.x}
            cy={24 + c.y}
            r={c.r}
            fill="hsl(var(--accent))"
            initial={{ opacity: 0, scale: 0 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2 + c.delay, type: "spring", stiffness: 200, damping: 14 }}
          />
        ) : (
          <circle key={i} cx={24 + c.x} cy={24 + c.y} r={c.r} fill="hsl(var(--accent))" opacity="0.85" />
        )
      )}
    </svg>
  );
}