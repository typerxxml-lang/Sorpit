import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "@/api/client";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import { Loader2, Check } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import Background from "@/components/Background";
import { toast } from "@/components/ui/use-toast";

/**
 * Full-screen gate shown until the user explicitly accepts the terms.
 * Returns null once accepted, so it can sit inside the app shell.
 */
export default function TermsGate() {
  const { user, checkUserAuth } = useAuth();
  const navigate = useNavigate();
  const [accepting, setAccepting] = useState(false);
  const [accepted, setAccepted] = useState(false);
  const TERMS_KEY = "sorpit-terms-accepted";

  if (user?.data?.terms_accepted_at || accepted || localStorage.getItem(TERMS_KEY)) return null;

  const accept = async () => {
    setAccepting(true);
    try { localStorage.setItem(TERMS_KEY, new Date().toISOString()); } catch (e) { /* ignore */ }
    setAccepted(true);
    try {
      await api.auth.updateMe({ terms_accepted_at: new Date().toISOString() });
    } catch (e) {
      /* server persist best-effort; gate already dismissed locally */
    }
    navigate("/app", { replace: true });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center px-6">
      <Background />
      <div className="glass relative z-10 w-full max-w-md rounded-[2rem] p-8 text-center">
        <BrandLogo size={64} className="mx-auto" />
        <h1 className="mt-4 text-xl font-extrabold">مرحبًا بك في Sorpit</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          قبل البدء، يرجى الاطلاع على الشروط والأحكام وسياسة الخصوصية والموافقة عليها صراحةً.
        </p>
        <div className="mt-4 flex justify-center gap-3 text-sm">
          <button onClick={() => navigate("/terms")} className="font-bold" style={{ color: "hsl(var(--accent))" }}>
            الشروط والأحكام
          </button>
          <span className="text-muted-foreground">·</span>
          <button onClick={() => navigate("/privacy")} className="font-bold" style={{ color: "hsl(var(--accent))" }}>
            سياسة الخصوصية
          </button>
        </div>
        <Button onClick={accept} disabled={accepting} className="mt-6 w-full rounded-2xl">
          {accepting ? <Loader2 className="h-4 w-4 animate-spin" /> : (<><Check className="h-4 w-4" /> أوافق وأبدأ الآن</>)}
        </Button>
      </div>
    </div>
  );
}