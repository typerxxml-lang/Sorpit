import { createContext, useContext, useState } from "react";
import ItemEditor from "@/components/ItemEditor";

const Ctx = createContext(null);

export function useItemEditor() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useItemEditor must be used within ItemEditorProvider");
  return ctx;
}

export default function ItemEditorProvider({ children }) {
  const [state, setState] = useState(null);

  const openItem = (item) => setState({ item });
  const openCreate = (type, presetProjectId, presetFolderId) =>
    setState({ type, presetProjectId, presetFolderId });
  const close = () => setState(null);

  return (
    <Ctx.Provider value={{ openItem, openCreate }}>
      {children}
      <ItemEditor
        open={!!state}
        onOpenChange={(o) => !o && close()}
        item={state?.item}
        type={state?.item?.type || state?.type}
        presetProjectId={state?.presetProjectId}
        presetFolderId={state?.presetFolderId}
      />
    </Ctx.Provider>
  );
}