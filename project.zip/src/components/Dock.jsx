import { useEffect, useRef, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { Home, FolderKanban, LayoutGrid, Star, Settings } from "lucide-react";
import { applyGlass } from "@/lib/glass";

const TABS = [
  { value: "home", label: "مساحتي", icon: Home, path: "/app" },
  { value: "projects", label: "المشاريع", icon: FolderKanban, path: "/app/projects" },
  { value: "library", label: "المكتبة", icon: LayoutGrid, path: "/app/library" },
  { value: "favorites", label: "المفضلة", icon: Star, path: "/app/favorites" },
  { value: "settings", label: "الإعدادات", icon: Settings, path: "/app/settings" },
];

export default function Dock() {
  const navigate = useNavigate();
  const location = useLocation();
  const dockRef = useRef(null);
  const pillRef = useRef(null);
  const rafRef = useRef(0);
  const firstRef = useRef(true);

  const px = useRef(0);
  const pv = useRef(0);
  const tx = useRef(0);
  const ty = useRef(0);
  const ls = useRef(0);
  const lv = useRef(0);
  const lt = useRef(0);
  const pw = useRef(0);
  const drag = useRef(false);
  const [active, setActive] = useState("home");

  useEffect(() => {
    const match =
      TABS.find((t) =>
        t.path === "/app" ? location.pathname === "/app" : location.pathname.startsWith(t.path)
      ) || TABS[0];
    setActive(match.value);
  }, [location.pathname]);

  const tabsEls = () => [...(dockRef.current?.querySelectorAll("[data-v]") || [])];

  const pos = () => {
    const btn = dockRef.current?.querySelector(`[data-v="${active}"]`);
    if (!btn || !pillRef.current) return;
    const b = btn.getBoundingClientRect();
    pw.current = b.width - 8;
    pillRef.current.style.width = pw.current + "px";
    pillRef.current.style.height = b.height - 8 + "px";
    tx.current = b.left + 4;
    ty.current = b.top + 4;
    if (firstRef.current) {
      px.current = tx.current;
      firstRef.current = false;
    }
    go();
  };

  const go = () => {
    if (!rafRef.current) rafRef.current = requestAnimationFrame(step);
  };
  const step = () => {
    rafRef.current = 0;
    pv.current += (tx.current - px.current) * 0.17;
    pv.current *= 0.74;
    px.current += pv.current;
    lv.current += (lt.current - ls.current) * 0.22;
    lv.current *= 0.68;
    ls.current += lv.current;
    const a = Math.abs(pv.current);
    const sx = (1 + ls.current * 0.3) * (1 + Math.min(a * 0.012, 0.28));
    const sy = (1 + ls.current * 0.3) * (1 - Math.min(a * 0.008, 0.18));
    if (pillRef.current) {
      pillRef.current.style.transform = `translate(${px.current}px, ${ty.current - ls.current * 8}px) scale(${sx},${sy})`;
    }
    if (
      Math.abs(tx.current - px.current) > 0.1 ||
      a > 0.1 ||
      Math.abs(lt.current - ls.current) > 0.002 ||
      Math.abs(lv.current) > 0.002
    ) {
      go();
    }
  };

  const near = (c) => {
    let best;
    let bd = 1e9;
    tabsEls().forEach((b) => {
      const r = b.getBoundingClientRect();
      const d = Math.abs(r.left + r.width / 2 - c);
      if (d < bd) {
        bd = d;
        best = b;
      }
    });
    return best;
  };

  const sel = (b) => {
    if (!b) return;
    const tab = TABS.find((t) => t.value === b.dataset.v);
    setActive(b.dataset.v);
    tabsEls().forEach((x) => x.classList.toggle("on", x === b));
    if (tab) navigate(tab.path);
    requestAnimationFrame(() => setTimeout(pos, 50));
  };

  const mv = (clientX) => {
    const r = dockRef.current.getBoundingClientRect();
    tx.current = Math.max(r.left + 4, Math.min(r.right - 4 - pw.current, clientX - pw.current / 2));
    const n = near(clientX);
    tabsEls().forEach((x) => x.classList.toggle("on", x === n));
    go();
  };

  useEffect(() => {
    firstRef.current = true;
    pos();
    const onResize = () => {
      firstRef.current = true;
      pos();
    };
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  // real light refraction on the dock (Chromium only; CSS glass fallback elsewhere)
  useEffect(() => {
    if (dockRef.current) return applyGlass(dockRef.current, 32, 22, 70);
  }, []);

  const onDown = (e) => {
    drag.current = true;
    try {
      dockRef.current.setPointerCapture(e.pointerId);
    } catch (_) {
      /* noop */
    }
    pillRef.current?.classList.add("lift");
    dockRef.current.classList.add("press");
    lt.current = 1;
    mv(e.clientX);
  };
  const onMove = (e) => {
    if (drag.current) mv(e.clientX);
  };
  const onUp = () => {
    if (!drag.current) return;
    drag.current = false;
    pillRef.current?.classList.remove("lift");
    dockRef.current.classList.remove("press");
    lt.current = 0;
    const n = near(px.current + pw.current / 2);
    sel(n);
    go();
  };

  return (
    <>
      <nav
        ref={dockRef}
        className="glass dock"
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        aria-label="التنقل الرئيسي"
      >
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.value}
              data-v={t.value}
              className={active === t.value ? "on" : ""}
              onClick={(e) => {
                // keyboard / click fallback (touch is captured by pointer handlers)
                if (e.detail === 0) sel(e.currentTarget);
              }}
              type="button"
            >
              <Icon className="h-5 w-5" />
              <span className="dock-lbl">{t.label}</span>
            </button>
          );
        })}
      </nav>
      <div id="sorpit-pill" ref={pillRef} />
    </>
  );
}