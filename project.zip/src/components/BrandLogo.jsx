import { useState } from "react";
import Logo from "@/components/Logo";

// ضع صورة الشعار الرسمية في public/logo.png — وإذا ما وُجدت يظهر شعار Sorpit المرسوم
let logoMissing = false;

export default function BrandLogo({ size = 88, className = "", round = false }) {
  const [failed, setFailed] = useState(logoMissing);
  return (
    <div className={`relative shrink-0 ${className}`} style={{ width: size, height: size }}>
      {failed ? (
        <Logo size={size} />
      ) : (
        <img
          src="/logo.png"
          alt="Sorpit"
          onError={() => {
            logoMissing = true;
            setFailed(true);
          }}
          className={`h-full w-full object-contain ${round ? "rounded-full" : ""}`}
        />
      )}
    </div>
  );
}
