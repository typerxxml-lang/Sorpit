import { useNavigate } from "react-router-dom";
import { Search, Plus } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { useFileUrl } from "@/lib/useFileUrl";
import { useGlass } from "@/lib/glass";
import BrandLogo from "@/components/BrandLogo";
import CreateMenu from "@/components/CreateMenu";
import MoreMenu from "@/components/MoreMenu";
import NotificationsBell from "@/components/NotificationsBell";
import { Grid } from "lucide-react";
import { useState } from "react";

export default function AppHeader() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [createOpen, setCreateOpen] = useState(false);
  const [moreOpen, setMoreOpen] = useState(false);
  const headerGlass = useGlass(30, 24, 44);

  const name = user?.data?.display_name || user?.full_name || "مستخدمي";
  const avatarUri = user?.data?.avatar_uri;
  const { url: avatarUrl } = useFileUrl(avatarUri);
  const initial = (name || "S").trim().charAt(0);

  return (
    <header className="sticky top-0 z-30 px-3 pt-3 sm:px-6">
      <div ref={headerGlass} className="glass flex items-center justify-between gap-2 rounded-3xl px-4 py-2.5">
        <button
          onClick={() => navigate("/app")}
          className="flex items-center gap-3 text-right"
          type="button"
        >
          <BrandLogo size={34} />
          <div className="hidden sm:block">
            <p className="text-[11px] leading-none text-muted-foreground">أهلًا بك</p>
            <p className="max-w-[10rem] truncate text-sm font-bold leading-tight">{name}</p>
          </div>
        </button>

        <div className="flex items-center gap-2">
          <NotificationsBell />
          <button
            onClick={() => setMoreOpen(true)}
            className="glass-soft flex h-10 w-10 items-center justify-center rounded-2xl text-muted-foreground transition active:scale-90"
            aria-label="المزيد"
            type="button"
          >
            <Grid className="h-5 w-5" />
          </button>
          <button
            onClick={() => navigate("/app/search")}
            className="glass-soft flex h-10 w-10 items-center justify-center rounded-2xl text-muted-foreground transition active:scale-90"
            aria-label="بحث"
            type="button"
          >
            <Search className="h-5 w-5" />
          </button>
          <button
            onClick={() => setCreateOpen(true)}
            className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-3.5 text-sm font-bold transition active:scale-95"
            type="button"
          >
            <Plus className="h-5 w-5" />
            <span className="hidden sm:inline">جديد</span>
          </button>
          <button
            onClick={() => navigate("/app/settings")}
            className="glass-soft flex h-10 w-10 items-center justify-center overflow-hidden rounded-2xl transition active:scale-90"
            aria-label="الحساب"
            type="button"
          >
            {avatarUrl ? (
              <img src={avatarUrl} alt={name} className="h-full w-full object-cover" />
            ) : (
              <span
                className="flex h-full w-full items-center justify-center text-sm font-bold"
                style={{ color: "hsl(var(--accent))" }}
              >
                {initial}
              </span>
            )}
          </button>
        </div>
      </div>

      <CreateMenu open={createOpen} onOpenChange={setCreateOpen} />
      <MoreMenu open={moreOpen} onOpenChange={setMoreOpen} />
    </header>
  );
}