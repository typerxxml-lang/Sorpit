import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "@/api/client";
import { useCollection } from "@/lib/useCollection";
import { onDataChanged } from "@/lib/dataEvents";
import {
  FolderKanban,
  FileText,
  Image as ImageIcon,
  StickyNote,
  Link2,
  Star,
  Archive,
  Trash2,
  LayoutGrid,
  Plus,
  Loader2,
  ArrowLeft,
} from "lucide-react";
import { useItemEditor } from "@/components/ItemEditorProvider";
import { timeAgo, TYPE_META, stripHtml } from "@/lib/itemHelpers";
import { useAuth } from "@/lib/AuthContext";

const QUICK = [
  { label: "المشاريع", icon: FolderKanban, path: "/app/projects", color: "250 82% 72%" },
  { label: "الملفات", icon: FileText, path: "/app/files", color: "38 88% 58%" },
  { label: "النصوص", icon: StickyNote, path: "/app/notes", color: "199 85% 60%" },
  { label: "الصور", icon: ImageIcon, path: "/app/images", color: "346 80% 68%" },
  { label: "الروابط", icon: Link2, path: "/app/links", color: "176 72% 48%" },
  { label: "المفضلة", icon: Star, path: "/app/favorites", color: "38 88% 58%" },
  { label: "الأرشيف", icon: Archive, path: "/app/archive", color: "240 12% 60%" },
  { label: "السلة", icon: Trash2, path: "/app/trash", color: "0 72% 60%" },
];

export default function Home() {
  const navigate = useNavigate();
  const { openCreate } = useItemEditor();
  const { user } = useAuth();
  const [stats, setStats] = useState(null);
  const [tick, setTick] = useState(0);

  const recent = useCollection(
    () =>
      api.entities.Item.filter(
        { deleted_at: { $exists: false }, is_archived: { $ne: true } },
        { sort: "-updated_date", limit: 6 }
      ),
    []
  );
  const recentProjects = useCollection(
    () =>
      api.entities.Project.filter(
        { deleted_at: { $exists: false }, is_archived: { $ne: true } },
        { sort: "-updated_date", limit: 4, fields: ["name", "cover_color", "status"] }
      ),
    []
  );

  useEffect(() => {
    onDataChanged(() => setTick((t) => t + 1));
  }, []);

  useEffect(() => {
    let active = true;
    const activeQ = { deleted_at: { $exists: false }, is_archived: { $ne: true } };
    Promise.all([
      api.entities.Item.aggregate({ query: activeQ, groupBy: "type" }),
      api.entities.Project.count({ deleted_at: { $exists: false }, is_archived: { $ne: true } }),
      api.entities.Item.count({ ...activeQ, is_favorite: true }),
      api.entities.Item.count({ is_archived: true, deleted_at: { $exists: false } }),
      api.entities.Item.count({ deleted_at: { $exists: true } }),
    ])
      .then(([agg, projects, fav, arch, tr]) => {
        if (!active) return;
        const byType = {};
        (agg?.rows || []).forEach((r) => {
          byType[r.type] = r.count;
        });
        setStats({ byType, projects, fav, arch, tr });
      })
      .catch(() => active && setStats(null));
    return () => {
      active = false;
    };
  }, [tick]);

  const totalItems = stats ? (stats.byType.note + stats.byType.image + stats.byType.file + stats.byType.link) : 0;
  const hasData = totalItems > 0 || (recentProjects.items.length > 0);

  const statCards = [
    { label: "المشاريع", value: stats?.projects ?? "—", icon: FolderKanban, color: "250 82% 72%" },
    { label: "الملفات", value: stats?.byType?.file ?? 0, icon: FileText, color: "38 88% 58%" },
    { label: "النصوص", value: stats?.byType?.note ?? 0, icon: StickyNote, color: "199 85% 60%" },
    { label: "الصور", value: stats?.byType?.image ?? 0, icon: ImageIcon, color: "346 80% 68%" },
    { label: "الروابط", value: stats?.byType?.link ?? 0, icon: Link2, color: "176 72% 48%" },
    { label: "المفضلة", value: stats?.fav ?? 0, icon: Star, color: "38 88% 58%" },
    { label: "المؤرشف", value: stats?.arch ?? 0, icon: Archive, color: "240 12% 60%" },
    { label: "المحذوف", value: stats?.tr ?? 0, icon: Trash2, color: "0 72% 60%" },
  ];

  return (
    <div className="animate-fade-up space-y-7">
      {/* greeting */}
      <div>
        <h1 className="text-2xl font-extrabold">مساحتي</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          أهلًا بك{user?.data?.display_name ? `، ${user.data.display_name}` : ""} — هذه لوحة تحكمك الرقمية.
        </p>
      </div>

      {/* stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {statCards.map((s) => {
          const Icon = s.icon;
          return (
            <div key={s.label} className="glass-soft flex items-center gap-3 rounded-3xl p-4">
              <span
                className="flex h-11 w-11 items-center justify-center rounded-2xl"
                style={{ background: `hsl(${s.color} / 0.16)`, color: `hsl(${s.color})` }}
              >
                <Icon className="h-5 w-5" />
              </span>
              <div>
                <p className="text-2xl font-extrabold leading-none">{s.value}</p>
                <p className="mt-1 text-[11px] text-muted-foreground">{s.label}</p>
              </div>
            </div>
          );
        })}
      </div>

      {/* quick access */}
      <div>
        <h2 className="mb-3 text-sm font-bold text-muted-foreground">الوصول السريع</h2>
        <div className="grid grid-cols-4 gap-3 sm:grid-cols-8">
          {QUICK.map((q) => {
            const Icon = q.icon;
            return (
              <button
                key={q.label}
                onClick={() => navigate(q.path)}
                className="glass-soft flex flex-col items-center gap-2 rounded-3xl p-3 transition active:scale-95"
              >
                <span
                  className="flex h-10 w-10 items-center justify-center rounded-2xl"
                  style={{ background: `hsl(${q.color} / 0.16)`, color: `hsl(${q.color})` }}
                >
                  <Icon className="h-5 w-5" />
                </span>
                <span className="text-[11px] font-bold">{q.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* empty first-use */}
      {!hasData && !recent.loading && !recentProjects.loading && (
        <div className="glass rounded-[2rem] p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-3xl glass-pill">
            <Plus className="h-8 w-8" />
          </div>
          <h3 className="text-lg font-bold">ابدأ ببناء مساحتك</h3>
          <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
            أنشئ أول مشروع أو أضف أول عنصر لتبدأ تنظيم عالمك الرقمي في مكان واحد.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <button
              onClick={() => openCreate("project")}
              className="glass-pill flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition active:scale-95"
            >
              <FolderKanban className="h-4 w-4" /> مشروع جديد
            </button>
            <button
              onClick={() => openCreate("note")}
              className="glass-soft flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition active:scale-95"
            >
              <StickyNote className="h-4 w-4" /> أول ملاحظة
            </button>
          </div>
        </div>
      )}

      {/* recent projects */}
      {recentProjects.items.length > 0 && (
        <div>
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-sm font-bold text-muted-foreground">مشاريع حديثة</h2>
            <button onClick={() => navigate("/app/projects")} className="text-xs" style={{ color: "hsl(var(--accent))" }}>
              الكل
            </button>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {recentProjects.items.map((p) => (
              <button
                key={p.id}
                onClick={() => navigate(`/app/projects/${p.id}`)}
                className="glass-soft flex items-center gap-3 rounded-3xl p-4 text-right transition active:scale-[0.98]"
              >
                <span
                  className="h-10 w-2.5 shrink-0 rounded-full"
                  style={{ background: `hsl(${p.cover_color || "250 82% 72%"})` }}
                />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold">{p.name}</p>
                  <p className="text-[11px] text-muted-foreground">{timeAgo(p.updated_date || p.created_date)}</p>
                </div>
                <ArrowLeft className="h-4 w-4 text-muted-foreground" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* recent activity */}
      <div>
        <h2 className="mb-3 text-sm font-bold text-muted-foreground">النشاط الأخير</h2>
        {recent.loading ? (
          <div className="flex justify-center py-10">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : recent.items.length === 0 ? (
          <p className="py-6 text-center text-sm text-muted-foreground">لا يوجد نشاط بعد.</p>
        ) : (
          <div className="flex flex-col gap-2">
            {recent.items.map((it) => {
              const meta = TYPE_META[it.type] || TYPE_META.note;
              const Icon = meta.icon;
              return (
                <button
                  key={it.id}
                  onClick={() => navigate(
                    it.type === "image" ? "/app/images" : it.type === "file" ? "/app/files" : it.type === "link" ? "/app/links" : it.type === "note" ? "/app/notes" : "/app/library"
                  )}
                  className="glass-soft flex items-center gap-3 rounded-2xl p-3 text-right transition active:scale-[0.99]"
                >
                  <span
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl"
                    style={{ background: `hsl(${it.color || meta.color} / 0.16)`, color: `hsl(${it.color || meta.color})` }}
                  >
                    <Icon className="h-5 w-5" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-bold">{it.title}</p>
                    <p className="truncate text-[11px] text-muted-foreground">
                      {it.type === "note" ? stripHtml(it.content) : it.description || meta.label}
                    </p>
                  </div>
                  <span className="shrink-0 text-[10px] text-muted-foreground/70">{timeAgo(it.updated_date || it.created_date)}</span>
                </button>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}