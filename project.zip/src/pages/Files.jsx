import { FileText } from "lucide-react";
import ItemListPage from "@/components/ItemListPage";

export default function Files() {
  return (
    <ItemListPage
      title="الملفات"
      subtitle="كل مستنداتك وملفاتك"
      icon={FileText}
      filter={{ type: "file", deleted_at: { $exists: false }, is_archived: { $ne: true } }}
      emptyTitle="لا توجد ملفات بعد"
      emptyDesc="ارفع أول ملف لتبدأ مكتبتك الرقمية."
      createType="file"
      createLabel="رفع ملف"
    />
  );
}