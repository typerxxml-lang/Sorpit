import { Star } from "lucide-react";
import ItemListPage from "@/components/ItemListPage";

export default function Favorites() {
  return (
    <ItemListPage
      title="المفضلة"
      subtitle="عناصرك المميزة"
      icon={Star}
      filter={{ is_favorite: true, deleted_at: { $exists: false }, is_archived: { $ne: true } }}
      emptyTitle="لا مفضلات بعد"
      emptyDesc="علّم أي عنصر بنجمة لإضافته هنا."
    />
  );
}