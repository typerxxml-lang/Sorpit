import React, { useState } from "react";
import { Link } from "react-router-dom";
import { api } from "@/api/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { User, UserPlus, Lock, Eye, EyeOff, Loader2 } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import { safeReturnTo } from "@/lib/authReturnTo";

export default function Register() {
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const returnTo = safeReturnTo();
  const dest = returnTo === "/" ? "/app" : returnTo;

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirm) {
      setError("كلمتا المرور غير متطابقتين");
      return;
    }
    setLoading(true);
    try {
      await api.auth.register({ username: username.trim(), password, display_name: displayName.trim() });
      window.location.href = dest;
    } catch (err) {
      setError(err.message || "تعذّر إنشاء الحساب");
      setLoading(false);
    }
  };

  return (
    <AuthLayout
      title="إنشاء حساب"
      subtitle="يوزر وكلمة مرور بس، وتدخل من أي جوال"
      footer={
        <>
          عندك حساب؟{" "}
          <Link
            to={"/login" + (dest !== "/app" ? "?returnTo=" + encodeURIComponent(dest) : "")}
            className="font-bold text-primary hover:underline"
          >
            سجّل دخولك
          </Link>
        </>
      }
    >
      {error && <div className="mb-4 rounded-2xl bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="username">اسم المستخدم</Label>
          <div className="relative">
            <User className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              id="username"
              dir="auto"
              autoComplete="username"
              autoCapitalize="none"
              autoCorrect="off"
              spellCheck={false}
              autoFocus
              placeholder="مثال: abdullah"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="h-12 rounded-2xl ps-10"
              required
              minLength={3}
              maxLength={24}
            />
          </div>
          <p className="text-xs text-muted-foreground">من 3 إلى 24 خانة: حروف وأرقام و _ . -</p>
        </div>
        <div className="space-y-2">
          <Label htmlFor="display">الاسم الظاهر (اختياري)</Label>
          <div className="relative">
            <UserPlus className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              id="display"
              dir="auto"
              autoComplete="nickname"
              placeholder="اسمك اللي يبان في التطبيق"
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              className="h-12 rounded-2xl ps-10"
              maxLength={40}
            />
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="password">كلمة المرور</Label>
          <div className="relative">
            <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              id="password"
              dir="ltr"
              type={show ? "text" : "password"}
              autoComplete="new-password"
              placeholder="٦ خانات على الأقل"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="h-12 rounded-2xl ps-10 pe-11 text-start"
              required
              minLength={6}
            />
            <button
              type="button"
              onClick={() => setShow((s) => !s)}
              className="absolute end-3 top-1/2 -translate-y-1/2 text-muted-foreground"
              aria-label={show ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"}
            >
              {show ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="space-y-2">
          <Label htmlFor="confirm">تأكيد كلمة المرور</Label>
          <div className="relative">
            <Lock className="pointer-events-none absolute start-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden="true" />
            <Input
              id="confirm"
              dir="ltr"
              type={show ? "text" : "password"}
              autoComplete="new-password"
              placeholder="أعدها مرة ثانية"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              className="h-12 rounded-2xl ps-10 text-start"
              required
            />
          </div>
        </div>
        <Button type="submit" className="h-12 w-full rounded-2xl font-bold" disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "إنشاء الحساب"}
        </Button>
      </form>
    </AuthLayout>
  );
}
