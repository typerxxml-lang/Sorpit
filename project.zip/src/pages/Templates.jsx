import { useState } from "react";
import { api } from "@/api/client";
import { useCollection } from "@/lib/useCollection";
import { Plus, LayoutTemplate, Pencil, Trash2, Wand2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import TemplateEditor from "@/components/TemplateEditor";
import EmptyState from "@/components/EmptyState";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";

export default function Templates() {
  const { items, loading } = useCollection(
    () => api.entities.Template.filter({}, { sort: "-created_date", limit: 100 })
  );
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const apply = async (tpl) => {
    try {
      const bp = tpl.blueprint || {};
      if (tpl.target === "project") {
        const c = await api.entities.Project.create({ name: bp.title || tpl.name, description: tpl.description || "", tags: bp.tags || [] });
        await logActivity("create", `مشروع من قالب: ${c.name}`, { entity_type: "Project", entity_id: c.id });
      } else if (tpl.target === "task") {
        const c = await api.entities.Task.create({ title: bp.title || tpl.name, tags: bp.tags || [], status: "not_started", priority: "medium" });
        await logActivity("create", `مهمة من قالب: ${c.title}`, { entity_type: "Task", entity_id: c.id });
      } else {
        const c = await api.entities.Item.create({ type: tpl.item_type || "note", title: bp.title || tpl.name, tags: bp.tags || [], color: bp.color || "" });
        await logActivity("create", `عنصر من قالب: ${c.title}`, { entity_type: "Item", entity_id: c.id });
      }
      toast({ title: "تم التطبيق" });
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  const remove = async (t) => {
    try {
      await api.entities.Template.delete(t.id);
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="القوالب"
        subtitle="ابدأ بسرعة من قالب جاهز"
        action={
          <button onClick={() => { setEditing(null); setOpen(true); }} className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <Plus className="h-5 w-5" /> جديد
          </button>
        }
      />
      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا قوالب" description="أنشئ قالبًا لتطبيقه لاحقًا بنقرة." />
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {items.map((t) => (
            <div key={t.id} className="glass flex flex-col rounded-3xl p-4">
              <div className="glass-soft mb-3 flex h-12 w-12 items-center justify-center rounded-2xl">
                <LayoutTemplate className="h-6 w-6" style={{ color: "hsl(var(--accent))" }} />
              </div>
              <p className="font-bold leading-tight">{t.name}</p>
              {t.description && <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{t.description}</p>}
              <p className="mt-2 text-[11px] text-muted-foreground">{t.target === "item" ? "عنصر" : t.target === "project" ? "مشروع" : "مهمة"}</p>
              <div className="mt-3 flex gap-1">
                <button onClick={() => apply(t)} type="button" className="glass-pill flex flex-1 items-center justify-center gap-1 rounded-xl py-2 text-xs font-bold"><Wand2 className="h-3.5 w-3.5" /> تطبيق</button>
                <button onClick={() => { setEditing(t); setOpen(true); }} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Pencil className="h-4 w-4" /></button>
                <button onClick={() => remove(t)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Trash2 className="h-4 w-4 text-destructive" /></button>
              </div>
            </div>
          ))}
        </div>
      )}
      <TemplateEditor open={open} onOpenChange={setOpen} template={editing} />
    </div>
  );
}