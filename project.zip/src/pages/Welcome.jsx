import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowLeft, FileText, Image as ImageIcon, Link2, FolderKanban, StickyNote } from "lucide-react";
import BrandLogo from "@/components/BrandLogo";
import Background from "@/components/Background";
import { useAuth } from "@/lib/AuthContext";

const cards = [
  { icon: FolderKanban, label: "مشروع", from: { x: -180, y: -120, r: -8 } },
  { icon: ImageIcon, label: "صورة", from: { x: 170, y: -130, r: 10 } },
  { icon: FileText, label: "مستند", from: { x: -190, y: 110, r: 6 } },
  { icon: StickyNote, label: "ملاحظة", from: { x: 160, y: 120, r: -7 } },
  { icon: Link2, label: "رابط", from: { x: 0, y: 180, r: 4 } },
];

export default function Welcome() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();
  const [stage, setStage] = useState(0);

  useEffect(() => {
    if (isAuthenticated) navigate("/app", { replace: true });
  }, [isAuthenticated, navigate]);

  useEffect(() => {
    const t1 = setTimeout(() => setStage(1), 1400);
    const t2 = setTimeout(() => setStage(2), 2600);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, []);

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center px-6 text-center">
      <Background />

      <div className="relative z-10 flex h-32 w-32 items-center justify-center">
        {[0, 1.1].map((d) => (
          <span
            key={d}
            className="animate-ring pointer-events-none absolute h-24 w-24 rounded-full"
            style={{ border: "0.5px solid rgba(255,255,255,0.35)", animationDelay: `${d + 1}s` }}
          />
        ))}
        <motion.div
          initial={{ opacity: 0, scale: 0.5, rotate: -12 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          transition={{ type: "spring", stiffness: 110, damping: 13 }}
        >
          <motion.div
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
          >
            <BrandLogo size={96} className="mx-auto" />
          </motion.div>
        </motion.div>
      </div>

      <h1 className="relative z-10 mt-6 flex text-5xl font-extrabold tracking-tight text-glow" dir="ltr" aria-label="Sorpit">
        {"Sorpit".split("").map((ch, i) => (
          <motion.span
            key={i}
            aria-hidden="true"
            initial={{ opacity: 0, y: 26, scale: 0.8 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            transition={{ delay: 0.45 + i * 0.07, type: "spring", stiffness: 170, damping: 14 }}
            className="inline-block"
          >
            {ch}
          </motion.span>
        ))}
      </h1>
      <motion.p
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1, duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative z-10 mt-3 text-lg text-muted-foreground"
      >
        عالمك الرقمي، على طريقتك
      </motion.p>

      {/* converging cards */}
      <div className="relative z-10 mt-12 h-44 w-full max-w-md">
        {cards.map((c, i) => {
          const Icon = c.icon;
          return (
            <motion.div
              key={i}
              initial={{ x: c.from.x, y: c.from.y, opacity: 0, rotate: c.from.r, scale: 0.6 }}
              animate={
                stage >= 1
                  ? {
                      x: (i - 2) * 70,
                      y: (i % 2 === 0 ? -1 : 1) * 30,
                      opacity: 1,
                      rotate: 0,
                      scale: 1,
                    }
                  : {}
              }
              transition={{ delay: 0.1 + i * 0.12, type: "spring", stiffness: 120, damping: 16 }}
              className="absolute left-1/2 top-1/2 h-20 w-20"
              style={{ marginLeft: -40, marginTop: -40 }}
            >
              <motion.div
                animate={stage >= 2 ? { y: [0, -5, 0] } : {}}
                transition={{ duration: 3.4 + i * 0.35, repeat: Infinity, ease: "easeInOut", delay: i * 0.25 }}
                whileTap={{ scale: 0.92 }}
                className="glass-soft flex h-full w-full flex-col items-center justify-center gap-1 rounded-3xl"
              >
                <Icon className="h-6 w-6" style={{ color: "hsl(var(--accent))" }} />
                <span className="text-[11px] font-medium text-muted-foreground">{c.label}</span>
              </motion.div>
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {stage >= 2 && (
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ type: "spring", stiffness: 120, damping: 17 }}
            className="relative z-10 mt-10 flex w-full max-w-sm flex-col gap-3"
          >
            <p className="mb-2 text-xl font-bold">كل عالمك الرقمي، في مكان واحد</p>
            <button
              onClick={() => navigate("/login")}
              className="glass-pill group flex h-14 w-full items-center justify-center gap-2 rounded-2xl text-base font-bold text-foreground"
            >
              ابدأ الآن
              <ArrowLeft className="h-5 w-5 transition-transform duration-300 group-hover:-translate-x-1" />
            </button>
            <button
              onClick={() => navigate("/login")}
              className="h-11 w-full text-sm font-medium text-muted-foreground transition hover:text-foreground"
            >
              تخطي
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      <p className="relative z-10 mt-10 text-xs text-muted-foreground/70">
        بالمتابعة فإنك توافق على{" "}
        <span className="underline-offset-2 hover:underline">الشروط والأحكام</span> و{" "}
        <span className="underline-offset-2 hover:underline">سياسة الخصوصية</span>
      </p>
    </div>
  );
}