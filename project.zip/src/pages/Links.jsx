import { Link2 } from "lucide-react";
import ItemListPage from "@/components/ItemListPage";

export default function Links() {
  return (
    <ItemListPage
      title="الروابط"
      subtitle="مكتبة روابطك المحفوظة"
      icon={Link2}
      filter={{ type: "link", deleted_at: { $exists: false }, is_archived: { $ne: true } }}
      emptyTitle="لا توجد روابط بعد"
      emptyDesc="احفظ أول رابط لترجع إليه لاحقًا."
      createType="link"
      createLabel="إضافة رابط"
    />
  );
}