import { useState } from "react";
import { api } from "@/api/client";
import { useCollection } from "@/lib/useCollection";
import { Plus, CheckCircle2, Circle, Clock, PauseCircle, CircleDashed, Trash2, Pencil } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import TaskEditor from "@/components/TaskEditor";
import EmptyState from "@/components/EmptyState";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";

const STATUS_META = {
  not_started: { label: "لم تبدأ", icon: CircleDashed },
  in_progress: { label: "قيد التنفيذ", icon: Clock },
  completed: { label: "مكتملة", icon: CheckCircle2 },
  deferred: { label: "مؤجلة", icon: PauseCircle },
};
const PRIORITY_DOT = { low: "156 64% 48%", medium: "38 88% 58%", high: "231 100% 62%", urgent: "0 78% 56%" };

export default function Tasks() {
  const [filter, setFilter] = useState("all");
  const [editing, setEditing] = useState(null);
  const [open, setOpen] = useState(false);
  const query = filter === "all" ? {} : { status: filter };
  const { items, loading } = useCollection(
    () => api.entities.Task.filter(query, { sort: "-created_date", limit: 100 }),
    [filter]
  );

  const openNew = () => { setEditing(null); setOpen(true); };
  const openEdit = (t) => { setEditing(t); setOpen(true); };

  const quickToggle = async (t) => {
    const next = t.status === "completed" ? "not_started" : "completed";
    try {
      await api.entities.Task.update(t.id, { status: next });
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  const remove = async (t) => {
    try {
      await api.entities.Task.delete(t.id);
      await logActivity("delete", `حذف المهمة: ${t.title}`, { entity_type: "Task", entity_id: t.id });
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  const filters = ["all", "not_started", "in_progress", "completed", "deferred"];

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="المهام"
        subtitle="نظّم مهامك وقوائم التحقق"
        action={
          <button onClick={openNew} className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <Plus className="h-5 w-5" /> جديدة
          </button>
        }
      />
      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`shrink-0 rounded-2xl px-4 py-2 text-sm font-bold transition ${filter === f ? "glass-pill" : "glass-soft text-muted-foreground"}`}
          >
            {f === "all" ? "الكل" : STATUS_META[f].label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا مهام بعد" description="ابدأ بإضافة مهمتك الأولى." />
      ) : (
        <div className="space-y-3">
          {items.map((t) => {
            const done = (t.checklist || []).filter((c) => c.done).length;
            const total = (t.checklist || []).length;
            const SM = STATUS_META[t.status] || STATUS_META.not_started;
            const SIcon = SM.icon;
            return (
              <div key={t.id} className="glass rounded-3xl p-4">
                <div className="flex items-start gap-3">
                  <button onClick={() => quickToggle(t)} type="button" className="mt-0.5">
                    {t.status === "completed" ? <CheckCircle2 className="h-6 w-6" style={{ color: "hsl(var(--accent))" }} /> : <Circle className="h-6 w-6 text-muted-foreground" />}
                  </button>
                  <div className="min-w-0 flex-1">
                    <p className={`font-bold ${t.status === "completed" ? "line-through opacity-50" : ""}`}>{t.title}</p>
                    {t.description && <p className="mt-0.5 line-clamp-2 text-sm text-muted-foreground">{t.description}</p>}
                    <div className="mt-2 flex flex-wrap items-center gap-2 text-xs">
                      <span className="glass-soft flex items-center gap-1 rounded-full px-2.5 py-1"><SIcon className="h-3.5 w-3.5" /> {SM.label}</span>
                      <span className="flex items-center gap-1 rounded-full px-1"><span className="h-2 w-2 rounded-full" style={{ background: `hsl(${PRIORITY_DOT[t.priority] || PRIORITY_DOT.medium})` }} /> الأولوية</span>
                      {total > 0 && <span className="glass-soft rounded-full px-2.5 py-1">{done}/{total}</span>}
                      {t.due_date && <span className="glass-soft rounded-full px-2.5 py-1">{t.due_date}</span>}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button onClick={() => openEdit(t)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Pencil className="h-4 w-4" /></button>
                    <button onClick={() => remove(t)} type="button" className="glass-soft flex h-8 w-8 items-center justify-center rounded-xl"><Trash2 className="h-4 w-4 text-destructive" /></button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <TaskEditor open={open} onOpenChange={setOpen} task={editing} />
    </div>
  );
}