import { useState } from "react";
import { api } from "@/api/client";
import { useCollection } from "@/lib/useCollection";
import { Plus, Zap, Pencil, Trash2, Play } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import AutomationEditor from "@/components/AutomationEditor";
import EmptyState from "@/components/EmptyState";
import { Switch } from "@/components/ui/switch";
import { toast } from "@/components/ui/use-toast";
import { emitDataChanged } from "@/lib/dataEvents";
import { logActivity } from "@/lib/activityLog";

const TRIGGER_LABEL = { item_created: "عند إنشاء عنصر", item_updated: "عند تعديل عنصر", manual: "يدوي", scheduled: "مجدول" };
const ACTION_LABEL = { tag: "إضافة وسم", set_color: "تغيير اللون", move_folder: "نقل لمجلد", notify: "إشعار", archive: "أرشفة" };

export default function Automations() {
  const { items, loading } = useCollection(
    () => api.entities.AutomationRule.filter({}, { sort: "-created_date", limit: 100 })
  );
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);

  const toggle = async (r) => {
    try {
      await api.entities.AutomationRule.update(r.id, { is_active: !r.is_active });
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  const runManual = async (r) => {
    try {
      if (r.action_type === "notify") {
        await api.entities.Notification.create({
          title: `أتمتة: ${r.name}`,
          body: r.action_config?.value || "تم تشغيل القاعدة يدويًا",
          type: "system",
          is_read: false,
        });
      }
      await logActivity("manual_run", `تشغيل يدوي للأتمتة: ${r.name}`, { entity_type: "AutomationRule", entity_id: r.id });
      toast({ title: "تم التشغيل" });
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  const remove = async (r) => {
    try {
      await api.entities.AutomationRule.delete(r.id);
      emitDataChanged();
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="الأتمتة"
        subtitle="قواعد ثابتة تعمل تلقائيًا"
        action={
          <button onClick={() => { setEditing(null); setOpen(true); }} className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <Plus className="h-5 w-5" /> جديدة
          </button>
        }
      />
      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا قواعأ أتمتة" description="أنشئ قاعدة تعمل تلقائيًا عند تحقق شرط." />
      ) : (
        <div className="space-y-3">
          {items.map((r) => (
            <div key={r.id} className="glass flex items-center gap-3 rounded-3xl p-4">
              <div className="glass-soft flex h-10 w-10 shrink-0 items-center justify-center rounded-2xl">
                <Zap className="h-5 w-5" style={{ color: r.is_active ? "hsl(var(--accent))" : "hsl(var(--muted-foreground))" }} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="font-bold">{r.name}</p>
                <p className="text-xs text-muted-foreground">{TRIGGER_LABEL[r.trigger]} ← {ACTION_LABEL[r.action_type]}</p>
              </div>
              <Switch checked={!!r.is_active} onCheckedChange={() => toggle(r)} />
              {r.trigger === "manual" && (
                <button onClick={() => runManual(r)} type="button" className="glass-soft flex h-9 w-9 items-center justify-center rounded-xl"><Play className="h-4 w-4" /></button>
              )}
              <button onClick={() => { setEditing(r); setOpen(true); }} type="button" className="glass-soft flex h-9 w-9 items-center justify-center rounded-xl"><Pencil className="h-4 w-4" /></button>
              <button onClick={() => remove(r)} type="button" className="glass-soft flex h-9 w-9 items-center justify-center rounded-xl"><Trash2 className="h-4 w-4 text-destructive" /></button>
            </div>
          ))}
        </div>
      )}
      <AutomationEditor open={open} onOpenChange={setOpen} rule={editing} />
    </div>
  );
}