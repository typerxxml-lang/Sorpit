import { Image as ImageIcon } from "lucide-react";
import ItemListPage from "@/components/ItemListPage";

export default function Images() {
  return (
    <ItemListPage
      title="الصور"
      subtitle="معرض صورك الخاص"
      icon={ImageIcon}
      filter={{ type: "image", deleted_at: { $exists: false }, is_archived: { $ne: true } }}
      emptyTitle="لا توجد صور بعد"
      emptyDesc="أضف أول صورة من جهازك."
      createType="image"
      createLabel="إضافة صورة"
    />
  );
}