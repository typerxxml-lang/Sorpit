import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api } from "@/api/client";
import { useCollection } from "@/lib/useCollection";
import { onDataChanged } from "@/lib/dataEvents";
import { ArrowRight, Plus, Loader2, Pencil, Archive, Trash2, LayoutGrid, List } from "lucide-react";
import ItemCard from "@/components/ItemCard";
import ProjectEditor from "@/components/ProjectEditor";
import EmptyState from "@/components/EmptyState";
import ConfirmDialog from "@/components/ConfirmDialog";
import { useItemEditor } from "@/components/ItemEditorProvider";
import { PROJECT_STATUS } from "@/lib/itemHelpers";
import { toast } from "@/components/ui/use-toast";

export default function ProjectDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { openCreate } = useItemEditor();
  const [project, setProject] = useState(null);
  const [loadingP, setLoadingP] = useState(true);
  const [editorOpen, setEditorOpen] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [view, setView] = useState("grid");
  const [tick, setTick] = useState(0);

  const { items, loading } = useCollection(
    () => api.entities.Item.filter({ project_id: id, deleted_at: { $exists: false } }, { sort: "-updated_date", limit: 200 }),
    [id]
  );

  useEffect(() => {
    onDataChanged(() => setTick((t) => t + 1));
  }, []);

  useEffect(() => {
    let active = true;
    setLoadingP(true);
    api.entities.Project
      .get(id)
      .then((p) => active && setProject(p))
      .catch(() => active && setProject(null))
      .finally(() => active && setLoadingP(false));
    return () => {
      active = false;
    };
  }, [id, tick]);

  if (loadingP) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!project) {
    return <EmptyState title="المشروع غير موجود" description="ربما حُذف أو لا تملك صلاحية رؤيته." />;
  }

  const status = PROJECT_STATUS[project.status] || PROJECT_STATUS.new;
  const accent = project.cover_color || "250 82% 72%";

  const archive = () => {
    api.entities.Project
      .update(id, { is_archived: !project.is_archived })
      .then(() => { toast({ title: project.is_archived ? "أُلغي الأرشفة" : "أُرشف المشروع" }); onDataChanged(); })
      .catch((e) => toast({ title: "خطأ", description: e.message, variant: "destructive" }));
  };
  const del = () => {
    api.entities.Project
      .update(id, { deleted_at: new Date().toISOString() })
      .then(() => { toast({ title: "نُقل المشروع للسلة" }); navigate("/app/projects"); })
      .catch((e) => toast({ title: "خطأ", description: e.message, variant: "destructive" }));
  };

  return (
    <div className="animate-fade-up">
      <button
        onClick={() => navigate("/app/projects")}
        className="mb-4 inline-flex items-center gap-1.5 text-sm text-muted-foreground transition hover:text-foreground"
      >
        <ArrowRight className="h-4 w-4" /> المشاريع
      </button>

      <div className="glass relative overflow-hidden rounded-[2rem] p-5">
        <div className="absolute inset-x-0 top-0 h-1.5" style={{ background: `hsl(${accent})` }} />
        <div className="flex flex-wrap items-start justify-between gap-3 pt-1">
          <div className="min-w-0">
            <h1 className="text-2xl font-extrabold">{project.name}</h1>
            {project.description && <p className="mt-1 text-sm text-muted-foreground">{project.description}</p>}
            <span
              className="mt-3 inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-bold"
              style={{ background: `hsl(${status.color} / 0.16)`, color: `hsl(${status.color})` }}
            >
              {status.label}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => setEditorOpen(true)} className="glass-soft flex h-10 w-10 items-center justify-center rounded-2xl transition active:scale-90">
              <Pencil className="h-4 w-4" />
            </button>
            <button onClick={archive} className="glass-soft flex h-10 w-10 items-center justify-center rounded-2xl transition active:scale-90">
              <Archive className="h-4 w-4" />
            </button>
            <button onClick={() => setConfirmDelete(true)} className="glass-soft flex h-10 w-10 items-center justify-center rounded-2xl text-destructive transition active:scale-90">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="mb-4 mt-6 flex items-center justify-between">
        <h2 className="text-sm font-bold text-muted-foreground">محتويات المشروع ({items.length})</h2>
        <div className="flex items-center gap-2">
          <div className="glass-soft flex rounded-2xl p-1">
            <button onClick={() => setView("grid")} className={`flex h-8 w-8 items-center justify-center rounded-xl ${view === "grid" ? "glass-pill" : ""}`}>
              <LayoutGrid className="h-4 w-4" />
            </button>
            <button onClick={() => setView("list")} className={`flex h-8 w-8 items-center justify-center rounded-xl ${view === "list" ? "glass-pill" : ""}`}>
              <List className="h-4 w-4" />
            </button>
          </div>
          <button
            onClick={() => openCreate("note", id)}
            className="glass-pill flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold transition active:scale-95"
          >
            <Plus className="h-5 w-5" /> إضافة
          </button>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center py-16">
          <Loader2 className="h-7 w-7 animate-spin text-muted-foreground" />
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          title="المشروع فارغ"
          description="أضف نصوصًا أو صورًا أو ملفات أو روابط إلى هذا المشروع."
          action={
            <button
              onClick={() => openCreate("note", id)}
              className="glass-pill flex items-center gap-2 rounded-2xl px-5 py-3 text-sm font-bold transition active:scale-95"
            >
              <Plus className="h-4 w-4" /> إضافة عنصر
            </button>
          }
        />
      ) : (
        <div className={view === "grid" ? "grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" : "flex flex-col gap-2.5"}>
          {items.map((it) => (
            <ItemCard key={it.id} item={it} view={view} />
          ))}
        </div>
      )}

      <ProjectEditor open={editorOpen} onOpenChange={setEditorOpen} project={project} />
      <ConfirmDialog
        open={confirmDelete}
        onOpenChange={setConfirmDelete}
        title="حذف المشروع"
        description="سيُنقل المشروع إلى سلة المحذوفات. العناصر داخله تبقى كما هي ويمكن استعادة المشروع لاحقًا."
        confirmText="نقل للسلة"
        onConfirm={del}
      />
    </div>
  );
}