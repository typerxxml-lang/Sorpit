import { StickyNote } from "lucide-react";
import ItemListPage from "@/components/ItemListPage";

export default function Notes() {
  return (
    <ItemListPage
      title="النصوص والملاحظات"
      subtitle="كتاباتك وملاحظاتك"
      icon={StickyNote}
      filter={{ type: "note", deleted_at: { $exists: false }, is_archived: { $ne: true } }}
      emptyTitle="لا توجد ملاحظات بعد"
      emptyDesc="اكتب أول ملاحظة أو فكرة."
      createType="note"
      createLabel="ملاحظة جديدة"
    />
  );
}