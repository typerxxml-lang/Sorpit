import { useNavigate } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import Background from "@/components/Background";
import Logo from "@/components/Logo";

const SECTIONS = [
  {
    h: "البيانات التي نجمعها",
    p: "نجمع بيانات حسابك (البريد، اللقب، الصورة الشخصية) والمحتوى الذي تضيفه (المشاريع، النصوص، الصور، الملفات، الروابط). لا نضيف أي ميزة ذكاء اصطناعي ولا نحلل محتواك آليًا.",
  },
  {
    h: "عزل بيانات المستخدمين",
    p: "كل مستخدم له مساحته الخاصة المعزولة. لا يستطيع مستخدم رؤية مشاريع أو ملفات مستخدم آخر، ولا تظهر محتوياتك في نتائج بحث غيرك. تُطبَّق قواعد الوصول في الخلفية وليس في الواجهة فقط.",
  },
  {
    h: "تخزين الملفات",
    p: "تُرفع ملفاتك إلى تخزين خاص مرتبط بحسابك. لا يمكن الوصول إليها إلا بك أو بمن تمنحه رابط مشاركة صالح. لا تُجعل الملفات عامة تلقائيًا.",
  },
  {
    h: "المشاركة",
    p: "عند إنشاء رابط مشاركة، يصبح المحتوى المحدد فقط قابلًا للاطلاع من يملك الرابط. يمكنك إيقاف المشاركة أو انتهاء صلاحيتها متى شئت. لا نكشف المحتوى المرتبط غير المشارَك.",
  },
  {
    h: "استخدام البيانات",
    p: "نستخدم بياناتك لتشغيل التطبيق وعرض مساحتك فقط. لا نبيع بياناتك ولا نشاركها مع أطراف ثالثة لأغراض تسويقية.",
  },
  {
    h: "الاحتفاظ والحذف",
    p: "يمكنك حذف عناصرك في أي وقت، وتُنقل إلى سلة المحذوفات قبل الحذف النهائي. لطلب حذف الحساب بالكامل، تواصل مع الدعم.",
  },
  {
    h: "الأمان",
    p: "نستخدم آليات المصادقة الأصلية للمنصة لتسجيل الدخول. لا نخزّن كلمات المرور كنص مكشوف. أنت مسؤول عن حماية بيانات الدخول الخاصة بك.",
  },
  {
    h: "التحديثات",
    p: "قد نحدّث سياسة الخصوصية. سننبّهك عند وجود تغييرات جوهرية. استمرارك في استخدام التطبيق بعد التحديث يعد قبولًا به.",
  },
];

export default function Privacy() {
  const navigate = useNavigate();
  return (
    <div className="relative min-h-screen">
      <Background />
      <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
        <button
          onClick={() => navigate(-1)}
          className="glass-soft mb-6 inline-flex items-center gap-1.5 rounded-2xl px-4 py-2 text-sm font-bold transition active:scale-95"
        >
          <ArrowRight className="h-4 w-4" /> رجوع
        </button>
        <div className="glass rounded-[2rem] p-6 sm:p-8">
          <div className="mb-6 flex items-center gap-3">
            <Logo size={40} />
            <div>
              <h1 className="text-2xl font-extrabold">سياسة الخصوصية</h1>
              <p className="text-xs text-muted-foreground">آخر تحديث: 2026</p>
            </div>
          </div>
          <div className="space-y-5 leading-relaxed">
            {SECTIONS.map((s) => (
              <div key={s.h}>
                <h2 className="mb-1.5 text-base font-bold" style={{ color: "hsl(var(--accent))" }}>{s.h}</h2>
                <p className="text-sm text-muted-foreground">{s.p}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}