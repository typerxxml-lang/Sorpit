import { api } from "@/api/client";
import { useCollection } from "@/lib/useCollection";
import { History, Trash2 } from "lucide-react";
import PageHeader from "@/components/PageHeader";
import EmptyState from "@/components/EmptyState";
import { toast } from "@/components/ui/use-toast";
import { timeAgo } from "@/lib/itemHelpers";
import { emitDataChanged } from "@/lib/dataEvents";

export default function Activity() {
  const { items, loading } = useCollection(
    () => api.entities.ActivityLog.filter({}, { sort: "-created_date", limit: 200 })
  );

  const clearAll = async () => {
    try {
      await api.entities.ActivityLog.deleteMany({});
      emitDataChanged();
      toast({ title: "تم مسح السجل" });
    } catch (e) {
      toast({ title: "خطأ", description: e.message, variant: "destructive" });
    }
  };

  return (
    <div className="animate-fade-up">
      <PageHeader
        title="سجل النشاط"
        subtitle="آخر ما تم في مساحتك"
        action={
          <button onClick={clearAll} className="glass-soft flex h-10 items-center gap-1.5 rounded-2xl px-4 text-sm font-bold active:scale-95" type="button">
            <Trash2 className="h-4 w-4 text-destructive" /> مسح السجل
          </button>
        }
      />
      {loading ? (
        <div className="py-20 text-center text-sm text-muted-foreground">جارٍ التحميل…</div>
      ) : items.length === 0 ? (
        <EmptyState title="لا نشاط بعد" description="ستظهر أحدث إجراءاتك هنا." />
      ) : (
        <div className="relative space-y-1 pr-4">
          <div className="absolute bottom-2 right-2 top-2 w-px bg-border" />
          {items.map((a) => (
            <div key={a.id} className="relative flex items-start gap-3 py-2">
              <span className="absolute right-[-13px] top-3.5 h-3 w-3 rounded-full border-2 border-background" style={{ background: "hsl(var(--accent))" }} />
              <div className="glass-soft flex h-8 w-8 shrink-0 items-center justify-center rounded-xl">
                <History className="h-4 w-4 text-muted-foreground" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm">{a.description}</p>
                <p className="text-xs text-muted-foreground">{timeAgo(a.created_date)} · {a.action}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}