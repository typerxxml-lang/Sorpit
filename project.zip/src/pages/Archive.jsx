import { Archive } from "lucide-react";
import ItemListPage from "@/components/ItemListPage";

export default function ArchivePage() {
  return (
    <ItemListPage
      title="الأرشيف"
      subtitle="عناصر مؤرشفة دون حذف"
      icon={Archive}
      filter={{ is_archived: true, deleted_at: { $exists: false } }}
      emptyTitle="الأرشيف فارغ"
      emptyDesc="العناصر المؤرشفة ستظهر هنا. يمكنك استعادتها متى شئت."
    />
  );
}