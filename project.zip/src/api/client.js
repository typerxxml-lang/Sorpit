// واجهة التطبيق مع السيرفر (حسابات + بيانات + ملفات) — تشتغل مع public/_worker.js
const TOKEN_KEY = "sorpit_token";
const MAX_FILE_BYTES = 10 * 1024 * 1024;
const CHUNK = 600000;

const getToken = () => {
  try {
    return localStorage.getItem(TOKEN_KEY) || "";
  } catch (_) {
    return "";
  }
};
const setToken = (t) => {
  try {
    if (t) localStorage.setItem(TOKEN_KEY, t);
    else localStorage.removeItem(TOKEN_KEY);
  } catch (_) {
    /* ignore */
  }
};

async function call(path, { method = "POST", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  const t = getToken();
  if (auth && t) headers.Authorization = "Bearer " + t;
  let res;
  try {
    res = await fetch("/api" + path, {
      method,
      headers,
      body: method === "GET" ? undefined : JSON.stringify(body || {}),
    });
  } catch (_) {
    const e = new Error("تعذّر الاتصال بالسيرفر، تأكد من الإنترنت");
    e.status = 0;
    throw e;
  }
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch (_) {
    /* not json */
  }
  if (!res.ok) {
    const e = new Error((data && data.error) || "صار خطأ، جرّب مرة ثانية");
    e.status = res.status;
    throw e;
  }
  if (data === null) {
    const e = new Error("السيرفر غير جاهز بعد (تأكد من ربط قاعدة البيانات)");
    e.status = 503;
    throw e;
  }
  return data;
}

const entity = (name) => {
  const run = (payload) => call(`/e/${name}`, { body: payload });
  return {
    create: (data) => run({ op: "create", data }),
    get: (id) => run({ op: "get", id }),
    update: (id, data) => run({ op: "update", id, data }),
    delete: (id) => run({ op: "delete", id }),
    filter: (query = {}, opts = {}) => run({ op: "filter", query, ...opts }),
    list: (sort, limit) => run({ op: "filter", query: {}, sort, limit }),
    count: (query = {}) => run({ op: "count", query }).then((r) => r.count),
    aggregate: ({ query = {}, groupBy }) => run({ op: "aggregate", query, groupBy }),
    updateMany: (query, update) => run({ op: "updateMany", query, update }),
    deleteMany: (query = {}) => run({ op: "deleteMany", query }),
  };
};

async function joinChunks(n, getChunk) {
  const parts = new Array(n);
  let next = 0;
  const worker = async () => {
    while (next < n) {
      const i = next++;
      parts[i] = (await getChunk(i)).data;
    }
  };
  await Promise.all([worker(), worker(), worker()].slice(0, Math.max(1, Math.min(3, n))));
  const dataUrl = parts.join("");
  const blob = await (await fetch(dataUrl)).blob();
  return URL.createObjectURL(blob);
}

async function uploadFile(file) {
  if (file.size > MAX_FILE_BYTES) throw new Error("حجم الملف أكبر من 10 ميجا");
  const dataUrl = await new Promise((resolve, reject) => {
    const r = new FileReader();
    r.onload = () => resolve(r.result);
    r.onerror = () => reject(new Error("تعذّرت قراءة الملف"));
    r.readAsDataURL(file);
  });
  const { file_id } = await call("/files/init", { body: { name: file.name, type: file.type, size: file.size } });
  const n = Math.ceil(dataUrl.length / CHUNK);
  for (let i = 0; i < n; i++) {
    await call(`/files/${file_id}/chunk`, { body: { idx: i, data: dataUrl.slice(i * CHUNK, (i + 1) * CHUNK) } });
  }
  await call(`/files/${file_id}/done`, { body: { chunks: n } });
  return file_id;
}

export const api = {
  auth: {
    hasToken: () => !!getToken(),
    me: () => call("/auth/me", { method: "GET" }),
    register: async ({ username, password, display_name }) => {
      const r = await call("/auth/register", { body: { username, password, display_name }, auth: false });
      setToken(r.token);
      return r.user;
    },
    login: async (username, password) => {
      const r = await call("/auth/login", { body: { username, password }, auth: false });
      setToken(r.token);
      return r.user;
    },
    updateMe: (patch) => call("/auth/update", { body: { patch } }),
    changePassword: (current, next) => call("/auth/password", { body: { current, next } }),
    clearToken: () => setToken(""),
    logout: async (redirectTo = "/login") => {
      try {
        if (getToken()) await call("/auth/logout");
      } catch (_) {
        /* ignore */
      }
      setToken("");
      window.location.href = redirectTo;
    },
  },
  entities: new Proxy({}, { get: (_, name) => (typeof name === "string" ? entity(name) : undefined) }),
  integrations: {
    Core: {
      UploadPrivateFile: async ({ file }) => ({ file_uri: await uploadFile(file) }),
      CreateFileSignedUrl: async ({ file_uri }) => {
        const meta = await call(`/files/${file_uri}`, { method: "GET" });
        const url = await joinChunks(meta.chunks, (i) => call(`/files/${file_uri}/chunk/${i}`, { method: "GET" }));
        return { signed_url: url };
      },
    },
  },
  functions: {
    invoke: async (name, payload = {}) => {
      if (name === "getShare") {
        const data = await call(`/share/${encodeURIComponent(payload.token)}`, { method: "GET", auth: false });
        return { data };
      }
      throw new Error("غير مدعوم");
    },
  },
  share: {
    fileUrl: (token, chunks) =>
      joinChunks(chunks, (i) => call(`/share/${encodeURIComponent(token)}/file/${i}`, { method: "GET", auth: false })),
  },
};
